<?php

include 'header.php';
include '../db.php';
include '../config.php';
include '../send_message.php';

$contacts = $conn->query("SELECT * FROM contacts ORDER BY last_message_at DESC");
$total_contacts = $contacts->num_rows;

$broadcast_success = false;
$sent_count = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message = trim($_POST['message'] ?? '');
    $numbers = $_POST['numbers'] ?? [];
    if (!empty($message) && !empty($numbers)) {
        foreach ($numbers as $phone) {
            $phone = preg_replace('/[^0-9]/', '', $phone);
            if (strlen($phone) < 10) continue;
            $response = sendWhatsApp($phone, $message, $ACCESS_TOKEN, $PHONE_NUMBER_ID);
            $json     = json_decode($response, true);
            $msg_id   = $json['messages'][0]['id'] ?? null;
            $stmt = $conn->prepare("INSERT INTO messages (wa_id, message_id, message, direction, created_at) VALUES (?, ?, ?, 'outgoing', NOW())");
            $stmt->bind_param("sss", $phone, $msg_id, $message);
            $stmt->execute();
            $sent_count++;
        }
        $broadcast_success = true;
    }
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<div class="bc-page">

    <!-- TOP BAR -->
    <div class="bc-topbar">
        <div>
            <h1 class="bc-title">Broadcast</h1>
            <p class="bc-subtitle">Send a message to multiple contacts at once</p>
        </div>
        <div class="bc-stats">
            <div class="bc-stat">
                <span class="bc-stat-num"><?= $total_contacts ?></span>
                <span class="bc-stat-label">Contacts</span>
            </div>
        </div>
    </div>

    <?php if($broadcast_success){ ?>
    <div class="bc-alert">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M22 4L12 14.01l-3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Broadcast sent to <strong><?= $sent_count ?></strong> contact<?= $sent_count != 1 ? 's' : '' ?> successfully.
    </div>
    <?php } ?>

    <form method="POST" class="bc-layout">

        <!-- COMPOSE (on mobile this comes first) -->
        <div class="bc-card bc-compose">
            <div class="bc-card-header">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
                    <path d="M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Compose Message
            </div>
            <div class="bc-compose-body">
                <div class="bc-field">
                    <label class="bc-label">Message</label>
                    <textarea name="message" class="bc-textarea"
                              placeholder="Write your broadcast message here…"
                              required
                              oninput="updatePreview(this.value)"></textarea>
                    <div class="bc-char-count"><span id="charCount">0</span> characters</div>
                </div>

                <div class="bc-preview-wrap">
                    <div class="bc-preview-label">
                        <svg viewBox="0 0 24 24" width="12" height="12" fill="none">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z" stroke="currentColor" stroke-width="2"/>
                            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
                        </svg>
                        Preview
                    </div>
                    <div class="bc-preview-bubble" id="previewBubble">
                        <span class="bc-preview-placeholder">Your message will appear here…</span>
                    </div>
                </div>

                <button type="submit" class="bc-send-btn" id="sendBtn">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
                        <path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Send Broadcast
                    <span class="bc-send-badge" id="sendBadge">0</span>
                </button>
            </div>
        </div>

        <!-- RECIPIENTS -->
        <div class="bc-card bc-recipients">
            <div class="bc-card-header">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <circle cx="9" cy="7" r="4" stroke="currentColor" stroke-width="2"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                Recipients
                <span class="bc-count" id="selectedCount">0 selected</span>
            </div>

            <div class="bc-select-all-row">
                <label class="bc-select-all-label">
                    <input type="checkbox" id="selectAll" onchange="toggleAll(this)">
                    <span>Select all</span>
                </label>
                <span class="bc-total-label"><?= $total_contacts ?> contacts</span>
            </div>

            <div class="bc-contacts-list">
                <?php
                $contacts->data_seek(0);
                while($row = $contacts->fetch_assoc()){
                    $initial = strtoupper(substr($row['wa_id'], 0, 1));
                ?>
                <label class="bc-contact-row">
                    <input type="checkbox" name="numbers[]"
                           value="<?= htmlspecialchars($row['wa_id']) ?>"
                           class="bc-checkbox"
                           onchange="updateCount()">
                    <div class="bc-contact-avatar"><?= $initial ?></div>
                    <span class="bc-contact-phone"><?= htmlspecialchars($row['wa_id']) ?></span>
                    <div class="bc-check-icon">
                        <svg viewBox="0 0 24 24" width="12" height="12" fill="none">
                            <path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                </label>
                <?php } ?>
            </div>
        </div>

    </form>
</div>

<?php include 'footer.php'; ?>

<script>
function updateCount(){
    const checked = document.querySelectorAll('.bc-checkbox:checked').length;
    document.getElementById('selectedCount').textContent = checked + ' selected';
    document.getElementById('sendBadge').textContent = checked;
    document.querySelectorAll('.bc-contact-row').forEach(row => {
        row.classList.toggle('bc-contact-checked', row.querySelector('.bc-checkbox').checked);
    });
    const all = document.querySelectorAll('.bc-checkbox').length;
    document.getElementById('selectAll').checked = checked === all && all > 0;
    document.getElementById('selectAll').indeterminate = checked > 0 && checked < all;
}
function toggleAll(el){
    document.querySelectorAll('.bc-checkbox').forEach(cb => { cb.checked = el.checked; });
    updateCount();
}
function updatePreview(val){
    const bubble = document.getElementById('previewBubble');
    document.getElementById('charCount').textContent = val.length;
    if(val.trim()){
        bubble.innerHTML = val.replace(/\n/g,'<br>');
        bubble.style.color = '';
    } else {
        bubble.innerHTML = '<span class="bc-preview-placeholder">Your message will appear here…</span>';
    }
}
</script>

<style>
/* ── Page ───────────────────────────────────────────────────── */
.bc-page {
    max-width: 1000px;
    margin: 0 auto;
    padding: 14px 0 40px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

/* ── Top bar ────────────────────────────────────────────────── */
.bc-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
}
.bc-title    { font-size: 20px; font-weight: 500; color: #1a1a2e; margin: 0; line-height: 1.2; }
.bc-subtitle { font-size: 12.5px; color: #b0b0b0; margin: 3px 0 0; }
.bc-stats {
    background: #fff; border: 0.5px solid #e8e8e8;
    border-radius: 12px; padding: 10px 20px;
    display: flex; align-items: center; gap: 8px;
}
.bc-stat       { display: flex; flex-direction: column; align-items: center; gap: 2px; }
.bc-stat-num   { font-size: 20px; font-weight: 500; color: #1a1a2e; line-height: 1; }
.bc-stat-label { font-size: 11px; color: #b0b0b0; text-transform: uppercase; letter-spacing: .05em; }

/* ── Alert ──────────────────────────────────────────────────── */
.bc-alert {
    display: flex; align-items: center; gap: 9px;
    background: #EAF3DE; border: 0.5px solid #C0DD97;
    border-radius: 10px; padding: 11px 16px;
    font-size: 13.5px; color: #27500A;
}
.bc-alert svg { color: #3B6D11; flex-shrink: 0; }

/* ── Layout: side-by-side on desktop ────────────────────────── */
.bc-layout {
    display: flex;
    gap: 16px;
    align-items: flex-start;
}

/* Compose on left, recipients on right (desktop) */
.bc-compose    { flex: 1; min-width: 0; order: 1; }
.bc-recipients {
    width: 300px; min-width: 300px;
    display: flex; flex-direction: column;
    max-height: calc(100vh - 180px);
    order: 2;
}

/* ── Card ───────────────────────────────────────────────────── */
.bc-card {
    background: #fff; border: 0.5px solid #e8e8e8;
    border-radius: 14px; overflow: hidden;
}
.bc-card-header {
    display: flex; align-items: center; gap: 8px;
    padding: 12px 16px; font-size: 13px; font-weight: 500;
    color: #1a1a2e; border-bottom: 0.5px solid #f0f0f0;
    background: #fafafa;
}
.bc-card-header svg { color: #7F77DD; }
.bc-count {
    margin-left: auto; background: #EEEDFE; color: #534AB7;
    font-size: 11px; font-weight: 500; padding: 2px 9px; border-radius: 20px;
}

/* ── Recipients ─────────────────────────────────────────────── */
.bc-select-all-row {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 14px 8px; border-bottom: 0.5px solid #f5f5f5;
}
.bc-select-all-label {
    display: flex; align-items: center; gap: 8px;
    font-size: 12.5px; font-weight: 500; color: #555; cursor: pointer;
}
.bc-select-all-label input[type="checkbox"] {
    width: 15px; height: 15px; accent-color: #534AB7; cursor: pointer;
}
.bc-total-label { font-size: 11.5px; color: #c0c0c0; }

.bc-contacts-list {
    overflow-y: auto; flex: 1; padding: 6px 8px;
}
.bc-contacts-list::-webkit-scrollbar { width: 4px; }
.bc-contacts-list::-webkit-scrollbar-thumb { background: #e0e0e0; border-radius: 4px; }

.bc-contact-row {
    display: flex; align-items: center; gap: 9px;
    padding: 8px; border-radius: 8px;
    cursor: pointer; transition: background .12s;
    margin-bottom: 2px;
}
.bc-contact-row:hover            { background: #f5f5f5; }
.bc-contact-row.bc-contact-checked { background: #EEEDFE; }
.bc-contact-row input[type="checkbox"] { display: none; }

.bc-contact-avatar {
    width: 34px; height: 34px; min-width: 34px; border-radius: 50%;
    background: #EEEDFE; color: #534AB7;
    display: flex; align-items: center; justify-content: center;
    font-size: 13px; font-weight: 500; transition: background .12s;
}
.bc-contact-checked .bc-contact-avatar { background: #534AB7; color: #fff; }

.bc-contact-phone {
    font-size: 13px; color: #1a1a2e; flex: 1;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}

.bc-check-icon {
    width: 20px; height: 20px; border-radius: 50%;
    border: 0.5px solid #e0e0e0;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; transition: background .12s, border-color .12s;
}
.bc-check-icon svg { color: transparent; }
.bc-contact-checked .bc-check-icon { background: #534AB7; border-color: #534AB7; }
.bc-contact-checked .bc-check-icon svg { color: #fff; }

/* ── Compose ────────────────────────────────────────────────── */
.bc-compose-body {
    padding: 16px; display: flex; flex-direction: column; gap: 14px;
}
.bc-field  { display: flex; flex-direction: column; gap: 6px; }
.bc-label  {
    font-size: 11.5px; font-weight: 500; color: #888;
    text-transform: uppercase; letter-spacing: .05em;
}
.bc-textarea {
    width: 100%; box-sizing: border-box; min-height: 140px;
    padding: 12px 14px; font-size: 13.5px; line-height: 1.6;
    border: 0.5px solid #e0e0e0; border-radius: 10px;
    background: #f9f9f9; color: #1a1a2e; outline: none;
    resize: vertical; transition: border-color .15s, background .15s;
    font-family: inherit;
}
.bc-textarea:focus { border-color: #7F77DD; background: #fff; }
.bc-textarea::placeholder { color: #c0c0c0; }
.bc-char-count { font-size: 11.5px; color: #c0c0c0; text-align: right; }

.bc-preview-wrap  { display: flex; flex-direction: column; gap: 7px; }
.bc-preview-label {
    display: flex; align-items: center; gap: 5px;
    font-size: 11px; font-weight: 500;
    text-transform: uppercase; letter-spacing: .06em; color: #b0b0b0;
}
.bc-preview-label svg { color: #b0b0b0; }
.bc-preview-bubble {
    background: #534AB7; color: #fff;
    border-radius: 12px 2px 12px 12px;
    padding: 10px 14px; font-size: 13.5px; line-height: 1.55;
    max-width: 80%; align-self: flex-end;
    word-break: break-word; min-height: 40px;
}
.bc-preview-placeholder { color: rgba(255,255,255,.4); font-style: italic; }

.bc-send-btn {
    display: flex; align-items: center; justify-content: center; gap: 8px;
    width: 100%; padding: 12px; background: #534AB7; color: #fff;
    border: none; border-radius: 10px; font-size: 14px; font-weight: 500;
    cursor: pointer; transition: background .15s;
}
.bc-send-btn:hover { background: #3C3489; }
.bc-send-badge {
    background: rgba(255,255,255,.25); border-radius: 20px;
    font-size: 11.5px; font-weight: 500; padding: 2px 8px;
    min-width: 20px; text-align: center;
}

/* ══════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════ */

/* Tablet */
@media (max-width: 768px) {
    .bc-recipients { width: 260px; min-width: 260px; }
}

/* Mobile: stack vertically, compose on top */
@media (max-width: 600px) {
    .bc-page    { padding: 12px 0 32px; gap: 12px; }
    .bc-title   { font-size: 18px; }
    .bc-stats   { display: none; }

    .bc-layout {
        flex-direction: column;
    }

    /* Compose first, recipients second */
    .bc-compose    { order: 1; width: 100%; }
    .bc-recipients {
        order: 2;
        width: 100%; min-width: 0;
        max-height: none; /* don't cap — let it show all contacts */
    }

    /* On mobile, contacts list shows as a grid of tappable pills */
    .bc-contacts-list {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        padding: 12px;
        max-height: 240px; /* scroll if many contacts */
        overflow-y: auto;
    }

    .bc-contact-row {
        flex-direction: row;
        align-items: center;
        gap: 7px;
        padding: 7px 12px 7px 8px;
        border: 0.5px solid #e8e8e8;
        border-radius: 30px;
        background: #fafafa;
        margin-bottom: 0;
        width: auto;
    }
    .bc-contact-row.bc-contact-checked {
        background: #EEEDFE;
        border-color: #CECBF6;
    }

    /* Smaller avatar in pill */
    .bc-contact-avatar {
        width: 26px; height: 26px; min-width: 26px; font-size: 11px;
    }
    .bc-contact-phone { font-size: 12px; max-width: 120px; }

    /* Hide check circle — checked state shown by pill bg */
    .bc-check-icon { display: none; }

    .bc-card        { border-radius: 12px; }
    .bc-card-header { padding: 11px 14px; }
    .bc-compose-body { padding: 14px; gap: 12px; }
    .bc-textarea    { min-height: 110px; font-size: 13px; }

    /* Preview bubble full-width on mobile */
    .bc-preview-bubble { max-width: 100%; }

    .bc-send-btn { padding: 13px; font-size: 14px; }
}

/* Very small */
@media (max-width: 380px) {
    .bc-contact-phone { max-width: 90px; }
}
</style>