<?php

include '../config.php';
include '../send_template.php';

$phone = $_POST['phone'] ?? '';
$template = $_POST['template'] ?? 'sumahi_media';

if(empty($phone)){
    die("Phone missing");
}

$response = sendTemplate(
    $phone,
    $template,
    'en',
    $ACCESS_TOKEN,
    $PHONE_NUMBER_ID
);

$json = json_decode($response, true);

// CHECK SUCCESS PROPERLY
if(!isset($json['messages'][0]['id'])){
    file_put_contents(
        "template_error.txt",
        date('Y-m-d H:i:s')." FAILED: ".$response."\n",
        FILE_APPEND
    );

    header("Location: conversations.php?phone=".$phone."&error=template_failed");
    exit;
}

file_put_contents(
    "template_success.txt",
    date('Y-m-d H:i:s')." SUCCESS: ".$response."\n",
    FILE_APPEND
);

header("Location: conversations.php?phone=".$phone."&template_sent=1");
exit;