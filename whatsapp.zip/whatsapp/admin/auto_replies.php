<?php
include 'header.php';

if(isset($_POST['add'])){
    $keyword = trim($_POST['keyword']);
    $reply   = trim($_POST['reply']);
    if($keyword != '' && $reply != ''){
        $stmt = $conn->prepare("INSERT INTO auto_replies (keyword, reply_text, status) VALUES (?, ?, 1)");
        $stmt->bind_param("ss", $keyword, $reply);
        $stmt->execute();
    }
}

if(isset($_GET['toggle'])){
    $id = intval($_GET['toggle']);
    $conn->query("UPDATE auto_replies SET status = IF(status=1,0,1) WHERE id = $id");
    header("Location: auto_replies.php"); exit;
}

if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM auto_replies WHERE id = $id");
    header("Location: auto_replies.php"); exit;
}

$rows   = $conn->query("SELECT * FROM auto_replies ORDER BY id DESC");
$total  = $rows->num_rows;
$active = $conn->query("SELECT COUNT(*) as c FROM auto_replies WHERE status=1")->fetch_assoc()['c'];
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<div class="ar-page">

    <!-- PAGE HEADER -->
    <div class="ar-topbar">
        <div>
            <h1 class="ar-title">Auto Replies</h1>
            <p class="ar-subtitle">Keyword-triggered automatic responses</p>
        </div>
        <div class="ar-stats">
            <div class="ar-stat">
                <span class="ar-stat-num"><?= $total ?></span>
                <span class="ar-stat-label">Total</span>
            </div>
            <div class="ar-stat-divider"></div>
            <div class="ar-stat">
                <span class="ar-stat-num" style="color:#3B6D11"><?= $active ?></span>
                <span class="ar-stat-label">Active</span>
            </div>
            <div class="ar-stat-divider"></div>
            <div class="ar-stat">
                <span class="ar-stat-num" style="color:#993C1D"><?= $total - $active ?></span>
                <span class="ar-stat-label">Inactive</span>
            </div>
        </div>
    </div>

    <!-- ADD FORM CARD -->
    <div class="ar-card ar-form-card">
        <div class="ar-card-header">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
                <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
            New Auto Reply
        </div>
        <form method="POST" class="ar-form">
            <div class="ar-field">
                <label>Keyword</label>
                <input type="text" name="keyword" placeholder="e.g. hi, hello, price…" required>
                <span class="ar-field-hint">Triggers this reply when matched</span>
            </div>
            <div class="ar-field ar-field-grow">
                <label>Reply message</label>
                <input type="text" name="reply" placeholder="Type the automatic response…" required>
                <span class="ar-field-hint">Sent automatically when keyword is matched</span>
            </div>
            <div class="ar-field ar-field-btn">
                <label class="ar-label-spacer">&nbsp;</label>
                <button type="submit" name="add" class="ar-add-btn">
                    <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
                        <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    Add Reply
                </button>
            </div>
        </form>
    </div>

    <!-- RULES LIST -->
    <div class="ar-card">
        <div class="ar-card-header">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
                <path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
            All Rules
            <span class="ar-count"><?= $total ?></span>
        </div>

        <?php if($total == 0){ ?>
        <div class="ar-empty">
            <svg viewBox="0 0 24 24" width="40" height="40" fill="none" style="opacity:.2">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>
            </svg>
            <p>No auto replies yet. Add your first rule above.</p>
        </div>
        <?php } else { ?>

        <!-- Desktop table -->
        <div class="ar-table-wrap">
            <table class="ar-table">
                <thead>
                    <tr>
                        <th style="width:50px">#</th>
                        <th style="width:160px">Keyword</th>
                        <th>Reply message</th>
                        <th style="width:100px">Status</th>
                        <th style="width:110px">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                // Save rows for mobile cards too
                $allRows = [];
                while($r = $rows->fetch_assoc()) $allRows[] = $r;
                foreach($allRows as $r):
                ?>
                <tr>
                    <td class="ar-id"><?= $r['id'] ?></td>
                    <td><span class="ar-keyword"><?= htmlspecialchars($r['keyword']) ?></span></td>
                    <td class="ar-reply-text"><?= htmlspecialchars($r['reply_text']) ?></td>
                    <td>
                        <span class="ar-badge <?= $r['status']==1 ? 'ar-badge-active' : 'ar-badge-inactive' ?>">
                            <span class="ar-dot"></span>
                            <?= $r['status']==1 ? 'Active' : 'Inactive' ?>
                        </span>
                    </td>
                    <td>
                        <div class="ar-actions">
                            <a href="?toggle=<?= $r['id'] ?>" class="ar-btn-toggle" title="Toggle status">
                                <svg viewBox="0 0 24 24" width="14" height="14" fill="none">
                                    <path d="M18.36 6.64A9 9 0 1 1 5.63 5.63" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                    <path d="M12 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                </svg>
                            </a>
                            <a href="?delete=<?= $r['id'] ?>" onclick="return confirm('Delete this auto reply?')" class="ar-btn-delete" title="Delete">
                                <svg viewBox="0 0 24 24" width="14" height="14" fill="none">
                                    <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Mobile cards (hidden on desktop) -->
        <div class="ar-mobile-list">
            <?php foreach($allRows as $r): ?>
            <div class="ar-mobile-card">
                <div class="ar-mobile-card-top">
                    <span class="ar-keyword"><?= htmlspecialchars($r['keyword']) ?></span>
                    <span class="ar-badge <?= $r['status']==1 ? 'ar-badge-active' : 'ar-badge-inactive' ?>">
                        <span class="ar-dot"></span>
                        <?= $r['status']==1 ? 'Active' : 'Inactive' ?>
                    </span>
                </div>
                <p class="ar-mobile-reply"><?= htmlspecialchars($r['reply_text']) ?></p>
                <div class="ar-mobile-card-footer">
                    <span class="ar-id">#<?= $r['id'] ?></span>
                    <div class="ar-actions">
                        <a href="?toggle=<?= $r['id'] ?>" class="ar-btn-toggle" title="Toggle">
                            <svg viewBox="0 0 24 24" width="14" height="14" fill="none">
                                <path d="M18.36 6.64A9 9 0 1 1 5.63 5.63" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M12 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>
                            Toggle
                        </a>
                        <a href="?delete=<?= $r['id'] ?>" onclick="return confirm('Delete this auto reply?')" class="ar-btn-delete" title="Delete">
                            <svg viewBox="0 0 24 24" width="14" height="14" fill="none">
                                <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            Delete
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <?php } ?>
    </div>

</div>

<?php include 'footer.php'; ?>

<style>
/* ── Layout ─────────────────────────────────────────────────── */
.ar-page {
    max-width: 900px;
    margin: 0 auto;
    padding: 16px 0 40px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

/* ── Top bar ────────────────────────────────────────────────── */
.ar-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
}
.ar-title {
    font-size: 20px; font-weight: 500;
    color: #1a1a2e; margin: 0; line-height: 1.2;
}
.ar-subtitle { font-size: 12.5px; color: #b0b0b0; margin: 3px 0 0; }

.ar-stats {
    display: flex; align-items: center; gap: 20px;
    background: #fff; border: 0.5px solid #e8e8e8;
    border-radius: 12px; padding: 10px 20px;
}
.ar-stat { display: flex; flex-direction: column; align-items: center; gap: 2px; }
.ar-stat-num { font-size: 20px; font-weight: 500; color: #1a1a2e; line-height: 1; }
.ar-stat-label { font-size: 11px; color: #b0b0b0; text-transform: uppercase; letter-spacing: .05em; }
.ar-stat-divider { width: 0.5px; height: 28px; background: #e8e8e8; }

/* ── Card ───────────────────────────────────────────────────── */
.ar-card {
    background: #fff; border: 0.5px solid #e8e8e8;
    border-radius: 14px; overflow: hidden;
}
.ar-card-header {
    display: flex; align-items: center; gap: 8px;
    padding: 13px 18px; font-size: 13px; font-weight: 500;
    color: #1a1a2e; border-bottom: 0.5px solid #f0f0f0;
    background: #fafafa;
}
.ar-card-header svg { color: #7F77DD; }
.ar-count {
    margin-left: auto; background: #EEEDFE; color: #534AB7;
    font-size: 11px; font-weight: 500; padding: 2px 9px; border-radius: 20px;
}

/* ── Add form ───────────────────────────────────────────────── */
.ar-form {
    display: flex; gap: 12px;
    padding: 16px 18px; flex-wrap: wrap; align-items: flex-start;
}
.ar-field { display: flex; flex-direction: column; gap: 5px; min-width: 140px; }
.ar-field-grow { flex: 1; }
.ar-field-btn  { flex-shrink: 0; }
.ar-field label {
    font-size: 11.5px; font-weight: 500; color: #888;
    text-transform: uppercase; letter-spacing: .05em;
}
.ar-label-spacer { visibility: hidden; } /* keeps button aligned on desktop */
.ar-field input[type="text"] {
    padding: 9px 13px; font-size: 13.5px;
    border: 0.5px solid #e0e0e0; border-radius: 10px;
    background: #f9f9f9; color: #1a1a2e; outline: none;
    transition: border-color .15s, background .15s;
    width: 100%; box-sizing: border-box;
}
.ar-field input[type="text"]:focus { border-color: #7F77DD; background: #fff; }
.ar-field input[type="text"]::placeholder { color: #c0c0c0; }
.ar-field-hint { font-size: 11px; color: #c0c0c0; }
.ar-add-btn {
    display: flex; align-items: center; gap: 6px;
    padding: 9px 18px; background: #534AB7; color: #fff;
    border: none; border-radius: 10px; font-size: 13.5px; font-weight: 500;
    cursor: pointer; transition: background .15s; white-space: nowrap;
    width: 100%; justify-content: center;
}
.ar-add-btn:hover { background: #3C3489; }

/* ── Desktop table ──────────────────────────────────────────── */
.ar-table-wrap { overflow-x: auto; }
.ar-table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
.ar-table thead tr { background: #fafafa; border-bottom: 0.5px solid #f0f0f0; }
.ar-table th {
    padding: 10px 16px; font-size: 11px; font-weight: 500;
    text-transform: uppercase; letter-spacing: .06em;
    color: #b0b0b0; text-align: left; white-space: nowrap;
}
.ar-table td {
    padding: 12px 16px; border-bottom: 0.5px solid #f5f5f5;
    color: #1a1a2e; vertical-align: middle;
}
.ar-table tbody tr:last-child td { border-bottom: none; }
.ar-table tbody tr:hover td { background: #fafafa; }
.ar-id { font-size: 12px; color: #c0c0c0; font-weight: 500; }
.ar-keyword {
    display: inline-flex; align-items: center;
    background: #EEEDFE; color: #3C3489;
    font-size: 12.5px; font-weight: 500;
    padding: 4px 10px; border-radius: 6px;
}
.ar-reply-text { color: #444; font-size: 13px; max-width: 320px; }

/* Status badge */
.ar-badge {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 12px; font-weight: 500;
    padding: 4px 10px; border-radius: 20px; white-space: nowrap;
}
.ar-badge-active   { background: #EAF3DE; color: #27500A; }
.ar-badge-inactive { background: #f5f5f5; color: #999; }
.ar-dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
.ar-badge-active .ar-dot   { background: #3B6D11; }
.ar-badge-inactive .ar-dot { background: #ccc; }

/* Action buttons */
.ar-actions { display: flex; gap: 6px; align-items: center; }
.ar-btn-toggle,
.ar-btn-delete {
    width: 30px; height: 30px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    text-decoration: none; border: 0.5px solid #e8e8e8;
    transition: background .12s, border-color .12s;
}
.ar-btn-toggle { color: #7F77DD; background: #EEEDFE; border-color: #CECBF6; }
.ar-btn-toggle:hover { background: #CECBF6; }
.ar-btn-delete { color: #993C1D; background: #FAECE7; border-color: #F5C4B3; }
.ar-btn-delete:hover { background: #F5C4B3; }

/* Empty state */
.ar-empty {
    display: flex; flex-direction: column; align-items: center;
    gap: 10px; padding: 48px 20px;
    color: #c0c0c0; font-size: 13.5px;
}

/* ── Mobile cards (hidden on desktop) ───────────────────────── */
.ar-mobile-list { display: none; }

.ar-mobile-card {
    padding: 14px 16px;
    border-bottom: 0.5px solid #f0f0f0;
}
.ar-mobile-card:last-child { border-bottom: none; }

.ar-mobile-card-top {
    display: flex; align-items: center;
    justify-content: space-between; gap: 10px;
    margin-bottom: 8px;
}

.ar-mobile-reply {
    font-size: 13px; color: #444;
    line-height: 1.5; margin: 0 0 10px;
}

.ar-mobile-card-footer {
    display: flex; align-items: center;
    justify-content: space-between;
}

/* Wider action buttons with labels on mobile */
.ar-mobile-list .ar-btn-toggle,
.ar-mobile-list .ar-btn-delete {
    width: auto;
    height: 32px;
    padding: 0 12px;
    gap: 5px;
    font-size: 12px;
    font-weight: 500;
    border-radius: 8px;
}

/* ══════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════ */

/* Tablet */
@media (max-width: 768px) {
    .ar-stats { padding: 8px 16px; gap: 14px; }
    .ar-stat-num { font-size: 17px; }
}

/* Mobile */
@media (max-width: 600px) {
    .ar-page { padding: 12px 0 32px; gap: 12px; }

    .ar-title    { font-size: 18px; }
    .ar-subtitle { font-size: 12px; }

    /* Stats: compact single row */
    .ar-stats { padding: 8px 14px; gap: 12px; }
    .ar-stat-num   { font-size: 16px; }
    .ar-stat-label { font-size: 10px; }

    /* Form: stack vertically, full width */
    .ar-form { flex-direction: column; padding: 14px 14px; gap: 10px; }
    .ar-field,
    .ar-field-grow,
    .ar-field-btn  { width: 100%; min-width: 0; }
    .ar-label-spacer { display: none; } /* no wasted space on mobile */
    .ar-add-btn { width: 100%; justify-content: center; padding: 11px 18px; }

    .ar-card        { border-radius: 12px; }
    .ar-card-header { padding: 11px 14px; }

    /* Hide desktop table, show mobile cards */
    .ar-table-wrap  { display: none; }
    .ar-mobile-list { display: block; }
}

/* Very small */
@media (max-width: 380px) {
    .ar-stats { gap: 8px; padding: 7px 12px; }
    .ar-stat-divider { display: none; }
    .ar-stat-num { font-size: 15px; }
}
</style>