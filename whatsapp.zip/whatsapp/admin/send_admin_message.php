<?php

include '../db.php';
include '../config.php';
include '../send_message.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

/*
----------------------------------
ONLY ALLOW POST REQUEST
----------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: conversations.php");
    exit;
}

/*
----------------------------------
GET INPUT
----------------------------------
*/
$phone = trim($_POST['phone'] ?? '');
$message = trim($_POST['message'] ?? '');

/*
----------------------------------
VALIDATION
----------------------------------
*/
if (empty($phone) || empty($message)) {
    header("Location: conversations.php?phone=" . $phone . "&error=empty");
    exit;
}

/*
----------------------------------
CLEAN PHONE NUMBER
----------------------------------
*/
$phone = preg_replace('/[^0-9]/', '', $phone);

if (strlen($phone) < 10 || strlen($phone) > 15) {
    file_put_contents("logs.txt", "INVALID PHONE: $phone\n", FILE_APPEND);
    header("Location: conversations.php?phone=" . $phone . "&error=invalid_phone");
    exit;
}

/*
----------------------------------
SEND MESSAGE TO WHATSAPP
----------------------------------
*/
$response = sendWhatsApp(
    $phone,
    $message,
    $ACCESS_TOKEN,
    $PHONE_NUMBER_ID
);

/*
----------------------------------
LOG RESPONSE (IMPORTANT FOR DEBUG)
----------------------------------
*/
file_put_contents(
    "logs.txt",
    date('Y-m-d H:i:s') . " RESPONSE: " . $response . PHP_EOL,
    FILE_APPEND
);

$json = json_decode($response, true);

/*
----------------------------------
CHECK API ERROR
----------------------------------
*/
if (isset($json['error'])) {

    file_put_contents(
        "logs.txt",
        "API ERROR: " . $json['error']['message'] . PHP_EOL,
        FILE_APPEND
    );

    header("Location: conversations.php?phone=" . $phone . "&error=" . urlencode($json['error']['message']));
    exit;
}

/*
----------------------------------
CHECK SUCCESS RESPONSE
----------------------------------
*/
if (!isset($json['messages'][0]['id'])) {

    file_put_contents(
        "logs.txt",
        "UNKNOWN FAILURE: " . $response . PHP_EOL,
        FILE_APPEND
    );

    header("Location: conversations.php?phone=" . $phone . "&error=send_failed");
    exit;
}

/*
----------------------------------
GET MESSAGE ID
----------------------------------
*/
$message_id = $json['messages'][0]['id'];

/*
----------------------------------
SAVE MESSAGE IN DB (SAFE QUERY)
----------------------------------
*/
$stmt = $conn->prepare("
    INSERT INTO messages (wa_id, message_id, message, direction, created_at)
    VALUES (?, ?, ?, 'outgoing', NOW())
");

$stmt->bind_param("sss", $phone, $message_id, $message);
$stmt->execute();

/*
----------------------------------
UPDATE CONTACT
----------------------------------
*/
$stmt = $conn->prepare("
    UPDATE contacts
    SET last_message_at = NOW()
    WHERE wa_id = ?
");

$stmt->bind_param("s", $phone);
$stmt->execute();

/*
----------------------------------
SUCCESS REDIRECT
----------------------------------
*/
header("Location: conversations.php?phone=" . $phone . "&success=1");
exit;