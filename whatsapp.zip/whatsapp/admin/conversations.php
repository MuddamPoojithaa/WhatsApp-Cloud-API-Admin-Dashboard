<?php

include 'header.php';

$contacts = $conn->query("
    SELECT *
    FROM contacts
    ORDER BY last_message_at DESC
");

$selectedPhone = $_GET['phone'] ?? '';

if (!$selectedPhone && $contacts && $contacts->num_rows > 0) {
    $first = $contacts->fetch_assoc();
    $selectedPhone = $first['wa_id'];
    $contacts->data_seek(0);
}

if ($selectedPhone) {
    $stmt = $conn->prepare("
        INSERT INTO contacts (wa_id, last_message_at)
        VALUES (?, NOW())
        ON DUPLICATE KEY UPDATE last_message_at = NOW()
    ");
    $stmt->bind_param("s", $selectedPhone);
    $stmt->execute();
}

// Mobile: detect if a phone is selected — we'll show chat panel full-screen on mobile
$showChat = !empty($selectedPhone);

?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<h1 class="page-title">
    <?php if($showChat): ?>
        <!-- Back button shown on mobile only -->
        <a href="conversations.php" class="back-btn" aria-label="Back to contacts">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
                <path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </a>
    <?php endif; ?>
    Conversations
</h1>

<div class="chat-wrapper <?= $showChat ? 'chat-open' : '' ?>">

    <!-- CONTACTS PANEL -->
    <div class="contacts-panel">
        <div class="new-chat-box">
            <form method="GET" class="new-chat-form">
                <input type="text" name="phone" placeholder="New chat number…" required>
                <button type="submit" class="add-btn" aria-label="Start new chat">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
                        <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </button>
            </form>
        </div>

        <div class="contacts-label">Recent</div>

        <div class="contacts-list">
        <?php while($contact = $contacts->fetch_assoc()){ ?>
            <a href="?phone=<?= htmlspecialchars($contact['wa_id']) ?>"
               class="contact-item <?= ($selectedPhone == $contact['wa_id']) ? 'active' : '' ?>">
                <div class="contact-avatar">
                    <?= strtoupper(substr($contact['wa_id'], 0, 1)) ?>
                </div>
                <div class="contact-info">
                    <div class="contact-phone"><?= htmlspecialchars($contact['wa_id']) ?></div>
                    <div class="contact-time"><?= htmlspecialchars($contact['last_message_at']) ?></div>
                </div>
            </a>
        <?php } ?>
        </div>
    </div>

    <!-- CHAT PANEL -->
    <div class="chat-panel">

        <?php if($selectedPhone){ ?>

        <div class="chat-header">
            <!-- Mobile back arrow inside header too (within chat header) -->
            <a href="conversations.php" class="chat-back-btn" aria-label="Back">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
                    <path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
            <div class="chat-header-avatar">
                <?= strtoupper(substr($selectedPhone, 0, 1)) ?>
            </div>
            <div class="chat-header-info">
                <h3><?= htmlspecialchars($selectedPhone) ?></h3>
                <p>WhatsApp</p>
            </div>
            <div class="chat-header-actions">
                <button class="icon-btn" aria-label="Search">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
                        <circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.5"/>
                        <path d="M20 20l-3-3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                </button>
                <button class="icon-btn" aria-label="More options">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
                        <circle cx="12" cy="5" r="1.5" fill="currentColor"/>
                        <circle cx="12" cy="12" r="1.5" fill="currentColor"/>
                        <circle cx="12" cy="19" r="1.5" fill="currentColor"/>
                    </svg>
                </button>
            </div>
        </div>

        <div class="chat-messages" id="chatBox">
            <?php
            $stmt = $conn->prepare("SELECT * FROM messages WHERE wa_id = ? ORDER BY id ASC");
            $stmt->bind_param("s", $selectedPhone);
            $stmt->execute();
            $messages = $stmt->get_result();

            if($messages->num_rows > 0){
                while($msg = $messages->fetch_assoc()){
                    $class = ($msg['direction'] === "incoming") ? "incoming" : "outgoing";
                    echo '<div class="message ' . $class . '" data-id="' . $msg['id'] . '">'
                        . htmlspecialchars($msg['message'])
                        . '</div>';
                }
            } else {
                echo '<div class="empty-chat">
                    <svg viewBox="0 0 24 24" width="40" height="40" fill="none" style="opacity:.25">
                        <path d="M12 2C6.477 2 2 6.477 2 12c0 5.523 4.477 10 10 10 1.5 0 2.9-.3 4.2-.9L22 22l-1.1-5.8C21.6 14.9 22 13.5 22 12c0-5.523-4.477-10-10-10Z" stroke="currentColor" stroke-width="1.5"/>
                    </svg>
                    <span>Start your conversation</span>
                </div>';
            }
            ?>
        </div>

        <div class="input-area">
            <form method="POST" action="send_admin_message.php" class="chat-input-row">
                <input type="hidden" name="phone" value="<?= htmlspecialchars($selectedPhone) ?>">
                <button type="button" class="icon-btn" aria-label="Attach file">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
                        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 0 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                </button>
                <input type="text" name="message" placeholder="Type a message…" required>
                <button type="submit" class="send-btn" aria-label="Send message">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
                        <path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7Z" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </form>

            <div class="templates-row">
                <div class="templates-header">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" style="color:#534AB7">
                        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                    </svg>
                    Quick Send
                </div>
                <div class="templates-grid">
                    <form method="POST" action="send_template_message.php">
                        <input type="hidden" name="phone" value="<?= htmlspecialchars($selectedPhone) ?>">
                        <input type="hidden" name="template" value="sumahi_media">
                        <button type="submit" class="tpl-btn tpl-purple">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M12 3L21 8V16L12 21L3 16V8L12 3Z" stroke="currentColor" stroke-width="2"/></svg>
                            Welcome
                        </button>
                    </form>
                    <form method="POST" action="send_template_message.php">
                        <input type="hidden" name="phone" value="<?= htmlspecialchars($selectedPhone) ?>">
                        <input type="hidden" name="template" value="sumahi_services">
                        <button type="submit" class="tpl-btn tpl-blue">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M4 6H20M4 12H20M4 18H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
                            Services
                        </button>
                    </form>
                    <form method="POST" action="send_template_message.php">
                        <input type="hidden" name="phone" value="<?= htmlspecialchars($selectedPhone) ?>">
                        <input type="hidden" name="template" value="sumahi_pricing">
                        <button type="submit" class="tpl-btn tpl-green">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M12 3V21M17 7C17 5.343 14.761 4 12 4C9.239 4 7 5.343 7 7C7 8.657 9.239 10 12 10C14.761 10 17 11.343 17 13C17 14.657 14.761 16 12 16C9.239 16 7 14.657 7 13" stroke="currentColor" stroke-width="2"/></svg>
                            Pricing
                        </button>
                    </form>
                    <form method="POST" action="send_template_message.php">
                        <input type="hidden" name="phone" value="<?= htmlspecialchars($selectedPhone) ?>">
                        <input type="hidden" name="template" value="sumahi_support">
                        <button type="submit" class="tpl-btn tpl-coral">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M12 2C6.477 2 2 6.477 2 12C2 17.523 6.477 22 12 22C13.5 22 14.9 21.7 16.2 21.1L22 22L20.9 16.2C21.6 14.9 22 13.5 22 12C22 6.477 17.523 2 12 2Z" stroke="currentColor" stroke-width="2"/></svg>
                            Support
                        </button>
                    </form>
                    <form method="POST" action="send_template_message.php">
                        <input type="hidden" name="phone" value="<?= htmlspecialchars($selectedPhone) ?>">
                        <input type="hidden" name="template" value="sumahi_followup">
                        <button type="submit" class="tpl-btn tpl-amber">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M4 4V10H10M20 20V14H14M20 9A8 8 0 0 0 6 6L4 10M4 15A8 8 0 0 0 18 18L20 14" stroke="currentColor" stroke-width="2"/></svg>
                            Follow up
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <?php } else { ?>
            <div class="empty-chat full">
                <svg viewBox="0 0 24 24" width="48" height="48" fill="none" style="opacity:.2">
                    <path d="M12 2C6.477 2 2 6.477 2 12c0 5.523 4.477 10 10 10 1.5 0 2.9-.3 4.2-.9L22 22l-1.1-5.8C21.6 14.9 22 13.5 22 12c0-5.523-4.477-10-10-10Z" stroke="currentColor" stroke-width="1.5"/>
                </svg>
                <span>Select or start a new conversation</span>
            </div>
        <?php } ?>

    </div>
</div>

<?php include 'footer.php'; ?>

<script>
let chatBox = document.getElementById("chatBox");
let selectedPhone = new URLSearchParams(window.location.search).get("phone");
let lastId = 0;

if(chatBox){ chatBox.scrollTop = chatBox.scrollHeight; }

if(chatBox){
    let msgs = chatBox.querySelectorAll(".message[data-id]");
    if(msgs.length > 0){
        lastId = parseInt(msgs[msgs.length - 1].getAttribute("data-id")) || 0;
    }
}

setInterval(() => {
    if(!selectedPhone || !chatBox) return;
    fetch("fetch_messages.php?phone=" + encodeURIComponent(selectedPhone) + "&last_id=" + lastId)
    .then(r => r.json())
    .then(data => {
        if(!data.messages || data.messages.length === 0) return;
        data.messages.forEach(msg => {
            let div = document.createElement("div");
            div.className = "message " + msg.direction;
            div.setAttribute("data-id", msg.id);
            div.textContent = msg.message;
            chatBox.appendChild(div);
        });
        lastId = parseInt(data.messages[data.messages.length - 1].id);
        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(e => console.log(e));
}, 2000);
</script>

<style>
/* ── Page title ─────────────────────────────────────────────── */
.page-title {
    font-size: 18px;
    font-weight: 500;
    color: #1a1a2e;
    margin: -10px 0 8px;
    line-height: 1;
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Back button in title — desktop hidden, mobile shown */
.back-btn {
    display: none;
    align-items: center;
    justify-content: center;
    color: #534AB7;
    text-decoration: none;
    width: 28px;
    height: 28px;
    border-radius: 8px;
    flex-shrink: 0;
}
.back-btn:hover { background: #EEEDFE; }

/* ── Wrapper ────────────────────────────────────────────────── */
.chat-wrapper {
    display: flex;
    height: calc(100vh - 80px);
    max-height: calc(100vh - 80px);
    min-height: 480px;
    border-radius: 16px;
    overflow: hidden;
    border: 0.5px solid #e0e0e0;
    background: #fff;
    box-shadow: 0 2px 20px rgba(0,0,0,.06);
    margin-bottom: 16px;
}

/* ── Contacts panel ─────────────────────────────────────────── */
.contacts-panel {
    width: 300px;
    min-width: 300px;
    display: flex;
    flex-direction: column;
    border-right: 0.5px solid #ebebeb;
    background: #fafafa;
    overflow: hidden;
}
.new-chat-box {
    padding: 14px 12px;
    border-bottom: 0.5px solid #ebebeb;
    background: #fff;
}
.new-chat-form {
    display: flex;
    gap: 8px;
    align-items: center;
}
.new-chat-form input[type="text"] {
    flex: 1;
    padding: 9px 13px;
    font-size: 13px;
    border: 0.5px solid #ddd;
    border-radius: 10px;
    background: #f5f5f5;
    color: #1a1a2e;
    outline: none;
    transition: border-color .15s, background .15s;
}
.new-chat-form input[type="text"]:focus { border-color: #7F77DD; background: #fff; }
.new-chat-form input[type="text"]::placeholder { color: #b0b0b0; }
.add-btn {
    width: 36px; height: 36px; border-radius: 10px;
    background: #534AB7; border: none; color: #fff;
    cursor: pointer; display: flex; align-items: center;
    justify-content: center; flex-shrink: 0; transition: background .15s;
}
.add-btn:hover { background: #3C3489; }
.contacts-label {
    padding: 10px 16px 6px;
    font-size: 10.5px; font-weight: 500;
    letter-spacing: .07em; text-transform: uppercase; color: #b0b0b0;
}
.contacts-list { flex: 1; overflow-y: auto; }
.contact-item {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px; text-decoration: none;
    border-bottom: 0.5px solid #f0f0f0; transition: background .12s; cursor: pointer;
}
.contact-item:hover { background: #fff; }
.contact-item.active { background: #fff; border-left: 2.5px solid #7F77DD; }
.contact-avatar {
    width: 40px; height: 40px; min-width: 40px; border-radius: 50%;
    background: #EEEDFE; color: #534AB7;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; font-weight: 500;
}
.contact-info { flex: 1; min-width: 0; }
.contact-phone {
    font-size: 13px; font-weight: 500; color: #1a1a2e;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.contact-time { font-size: 11px; color: #b0b0b0; margin-top: 2px; }

/* ── Chat panel ─────────────────────────────────────────────── */
.chat-panel {
    flex: 1; display: flex; flex-direction: column;
    min-width: 0; background: #fff;
}

/* Chat header */
.chat-back-btn {
    display: none; /* hidden on desktop */
    align-items: center; justify-content: center;
    color: #534AB7; text-decoration: none;
    width: 32px; height: 32px; border-radius: 8px;
    flex-shrink: 0; margin-right: 2px;
}
.chat-back-btn:hover { background: #EEEDFE; }

.chat-header {
    padding: 13px 18px; border-bottom: 0.5px solid #ebebeb;
    display: flex; align-items: center; gap: 10px; background: #fff;
}
.chat-header-avatar {
    width: 38px; height: 38px; min-width: 38px; border-radius: 50%;
    background: #EEEDFE; color: #534AB7;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; font-weight: 500;
}
.chat-header-info h3 { font-size: 14px; font-weight: 500; color: #1a1a2e; }
.chat-header-info p  { font-size: 11.5px; color: #b0b0b0; margin-top: 1px; }
.chat-header-actions { margin-left: auto; display: flex; gap: 4px; }
.icon-btn {
    width: 34px; height: 34px; border-radius: 8px;
    border: 0.5px solid #e8e8e8; background: transparent;
    color: #888; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: background .12s, border-color .12s;
}
.icon-btn:hover { background: #f5f5f5; border-color: #ddd; color: #534AB7; }

/* Messages */
.chat-messages {
    flex: 1; overflow-y: auto;
    padding: 20px 20px 16px;
    display: flex; flex-direction: column; gap: 8px;
    background: #f7f7f8;
}
.message {
    max-width: 68%; padding: 10px 14px;
    font-size: 13.5px; line-height: 1.55; word-break: break-word;
}
.message.incoming {
    align-self: flex-start; background: #fff;
    border: 0.5px solid #e8e8e8; border-radius: 2px 12px 12px 12px; color: #1a1a2e;
}
.message.outgoing {
    align-self: flex-end; background: #534AB7;
    border-radius: 12px 2px 12px 12px; color: #fff;
}
.empty-chat {
    display: flex; flex-direction: column; align-items: center;
    justify-content: center; gap: 10px; padding: 40px 0;
    color: #b0b0b0; font-size: 13.5px;
}
.empty-chat.full { flex: 1; height: 100%; }

/* Input area */
.input-area {
    padding: 10px 14px 0;
    border-top: 0.5px solid #ebebeb;
    background: #fff; flex-shrink: 0;
}
.chat-input-row {
    display: flex; gap: 8px; align-items: center;
}
.chat-input-row input[type="text"] {
    flex: 1; padding: 10px 16px; font-size: 13.5px;
    border: 0.5px solid #e0e0e0; border-radius: 24px;
    background: #f5f5f5; color: #1a1a2e; outline: none;
    transition: border-color .2s, background .2s;
}
.chat-input-row input[type="text"]:focus { border-color: #7F77DD; background: #fff; }
.chat-input-row input[type="text"]::placeholder { color: #b0b0b0; }
.send-btn {
    width: 38px; height: 38px; border-radius: 50%;
    background: #534AB7; border: none; color: #fff;
    cursor: pointer; display: flex; align-items: center;
    justify-content: center; flex-shrink: 0; transition: background .15s;
}
.send-btn:hover { background: #3C3489; }

/* Templates */
.templates-row {
    background: #f9f8ff; border-top: 1px solid #e5e2f8;
    padding: 10px 14px 12px; flex-shrink: 0;
}
.templates-header {
    display: flex; align-items: center; gap: 6px;
    font-size: 11px; font-weight: 500;
    letter-spacing: .07em; text-transform: uppercase;
    color: #7F77DD; margin-bottom: 10px;
}
.templates-grid { display: flex; flex-wrap: wrap; gap: 7px; }
.templates-grid form { margin: 0; }
.tpl-btn {
    display: flex; align-items: center; gap: 6px;
    padding: 8px 14px; font-size: 12.5px; font-weight: 500;
    border-radius: 10px; cursor: pointer;
    transition: filter .15s, transform .12s;
    white-space: nowrap; border: none;
}
.tpl-btn:hover  { filter: brightness(.93); transform: translateY(-1px); }
.tpl-btn:active { transform: translateY(0); }
.tpl-purple { background: #EEEDFE; color: #3C3489; }
.tpl-purple svg { color: #534AB7; }
.tpl-blue   { background: #E6F1FB; color: #0C447C; }
.tpl-blue svg { color: #185FA5; }
.tpl-green  { background: #EAF3DE; color: #27500A; }
.tpl-green svg { color: #3B6D11; }
.tpl-coral  { background: #FAECE7; color: #712B13; }
.tpl-coral svg { color: #993C1D; }
.tpl-amber  { background: #FAEEDA; color: #633806; }
.tpl-amber svg { color: #854F0B; }

/* ══════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════ */

/* Tablet: narrow sidebar */
@media (max-width: 768px) {
    .chat-wrapper {
        height: calc(100vh - 70px);
        border-radius: 12px;
    }
    .contacts-panel {
        width: 220px;
        min-width: 220px;
    }
    .message { max-width: 80%; }
}

/* Mobile: full-screen panels, slide between them */
@media (max-width: 600px) {
    .chat-wrapper {
        height: calc(100dvh - 60px); /* dvh handles browser chrome better on mobile */
        border-radius: 12px;
        position: relative;
        overflow: hidden;
    }

    /* Both panels fill full width, sit side by side off-screen */
    .contacts-panel,
    .chat-panel {
        position: absolute;
        top: 0; bottom: 0;
        width: 100%;
        min-width: 100%;
        transition: transform 0.28s cubic-bezier(.4,0,.2,1);
    }

    /* Contacts always starts at 0 (visible by default) */
    .contacts-panel {
        left: 0;
        transform: translateX(0);
    }

    /* Chat panel starts off to the right */
    .chat-panel {
        left: 0;
        transform: translateX(100%);
    }

    /* When a chat is open: slide contacts out left, chat in */
    .chat-wrapper.chat-open .contacts-panel {
        transform: translateX(-100%);
    }
    .chat-wrapper.chat-open .chat-panel {
        transform: translateX(0);
    }

    /* Show back arrow inside chat header on mobile */
    .chat-back-btn {
        display: flex;
    }

    /* Wider sidebar inputs */
    .contacts-panel { width: 100%; min-width: 100%; }
    .contact-item   { padding: 12px 16px; }
    .contact-avatar { width: 44px; height: 44px; font-size: 15px; }
    .contact-phone  { font-size: 14px; }

    /* Messages slightly wider */
    .message { max-width: 85%; font-size: 13px; }
    .chat-messages { padding: 14px 14px 12px; }

    /* Templates: horizontal scroll instead of wrapping */
    .templates-row {
        padding: 8px 14px 10px;
    }
    .templates-grid {
        display: flex !important;
       
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch;
        padding-bottom: 6px;
        scrollbar-width: none;
        gap: 7px;
    }
    .templates-grid::-webkit-scrollbar { display: none; }
    .templates-grid form { flex-shrink: 0; margin: 0; }

    .tpl-btn {
        flex-shrink: 0;
        white-space: nowrap;
        padding: 7px 12px;
        font-size: 12px;
    }
}

/* Very small screens */
@media (max-width: 380px) {
    .chat-header { padding: 10px 12px; }
    .chat-header-info h3 { font-size: 13px; }
    .icon-btn { width: 30px; height: 30px; }
    .input-area { padding: 8px 10px 0; }
    .chat-input-row input[type="text"] { padding: 8px 12px; font-size: 13px; }
    .send-btn { width: 34px; height: 34px; }
}
</style>