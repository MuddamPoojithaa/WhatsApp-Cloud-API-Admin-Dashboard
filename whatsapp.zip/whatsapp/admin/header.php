<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include dirname(__DIR__) . '/db.php';

// Detect active page for nav highlighting
$current = basename($_SERVER['PHP_SELF']);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sumahi CRM</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
<style>

/* ── Reset ──────────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: #f5f5f7;
    color: #1a1a2e;
}

/* ── Sidebar ────────────────────────────────────────────────── */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 240px;
    height: 100vh;
    background: #0f172a;
    border-right: 0.5px solid rgba(255,255,255,.07);
    display: flex;
    flex-direction: column;
    z-index: 900;
    transition: transform .28s cubic-bezier(.4,0,.2,1);
    overflow: hidden;
}

/* ── Logo ───────────────────────────────────────────────────── */
.logo {
    display: flex;
    align-items: center;
    gap: 11px;
    padding: 20px 18px;
    border-bottom: 0.5px solid rgba(255,255,255,.07);
    flex-shrink: 0;
}

.logo-icon {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    background: #25D366;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 20px;
    flex-shrink: 0;
}

.logo-text h2 {
    color: #fff;
    font-size: 15px;
    font-weight: 600;
    line-height: 1.2;
}

.logo-text span {
    display: block;
    color: #64748b;
    font-size: 11px;
    margin-top: 1px;
}

/* ── Nav ────────────────────────────────────────────────────── */
.menu {
    flex: 1;
    padding: 14px 10px;
    overflow-y: auto;
}

.menu::-webkit-scrollbar { width: 0; }

.menu-title {
    color: #475569;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: .08em;
    font-weight: 600;
    padding: 0 10px 8px;
}

.sidebar a {
    display: flex;
    align-items: center;
    gap: 11px;
    color: #94a3b8;
    text-decoration: none;
    padding: 10px 12px;
    border-radius: 10px;
    margin-bottom: 2px;
    font-size: 13.5px;
    font-weight: 500;
    transition: background .15s, color .15s;
    white-space: nowrap;
}

.sidebar a i {
    font-size: 18px;
    width: 20px;
    flex-shrink: 0;
}

.sidebar a:hover {
    background: #1e293b;
    color: #e2e8f0;
}

.sidebar a.active {
    background: rgba(37,211,102,.12);
    color: #25D366;
    border: 0.5px solid rgba(37,211,102,.2);
}

.sidebar a.active i { color: #25D366; }

/* ── Footer user card ───────────────────────────────────────── */
.sidebar-footer {
    padding: 12px;
    border-top: 0.5px solid rgba(255,255,255,.07);
    flex-shrink: 0;
}

.admin-info {
    display: flex;
    align-items: center;
    gap: 10px;
    background: #1e293b;
    border-radius: 10px;
    padding: 10px 12px;
}

.admin-avatar {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    background: #534AB7;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    flex-shrink: 0;
}

.admin-name  { color: #e2e8f0; font-size: 13px; font-weight: 500; line-height: 1.2; }
.admin-role  { color: #64748b; font-size: 11px; margin-top: 1px; }

/* ── Top mobile bar ─────────────────────────────────────────── */
.topbar {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 56px;
    background: #0f172a;
    border-bottom: 0.5px solid rgba(255,255,255,.07);
    align-items: center;
    justify-content: space-between;
    padding: 0 16px;
    z-index: 901;
}

.topbar-logo {
    display: flex;
    align-items: center;
    gap: 9px;
}

.topbar-logo .logo-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    font-size: 17px;
}

.topbar-logo h2 {
    color: #fff;
    font-size: 15px;
    font-weight: 600;
}

.hamburger {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    background: #1e293b;
    border: none;
    color: #94a3b8;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    cursor: pointer;
    transition: background .15s, color .15s;
}

.hamburger:hover { background: #334155; color: #fff; }

/* ── Overlay ────────────────────────────────────────────────── */
.sidebar-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.5);
    z-index: 899;
    opacity: 0;
    transition: opacity .28s;
}

.sidebar-overlay.visible {
    opacity: 1;
}

/* ── Main content ───────────────────────────────────────────── */
.content {
    margin-left: 240px;
    padding: 24px 28px;
    min-height: 100vh;
}

/* ── Bottom mobile nav ──────────────────────────────────────── */
.bottom-nav {
    display: none;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 60px;
    background: #0f172a;
    border-top: 0.5px solid rgba(255,255,255,.07);
    z-index: 900;
    padding: 0 8px;
    align-items: center;
    justify-content: space-around;
}

.bottom-nav a {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 3px;
    color: #64748b;
    text-decoration: none;
    font-size: 10px;
    font-weight: 500;
    padding: 6px 10px;
    border-radius: 8px;
    transition: color .15s;
    flex: 1;
}

.bottom-nav a i { font-size: 20px; }

.bottom-nav a.active { color: #25D366; }
.bottom-nav a:hover  { color: #94a3b8; }

/* ── Responsive ─────────────────────────────────────────────── */
@media (max-width: 768px) {

    /* Show top bar and bottom nav */
    .topbar     { display: flex; }
    .bottom-nav { display: flex; }

    /* Slide sidebar off-screen by default */
    .sidebar {
        transform: translateX(-100%);
        width: 260px;
        top: 0;
        z-index: 902;
    }

    .sidebar.open {
        transform: translateX(0);
    }

    .sidebar-overlay {
        display: block;
    }

    /* Content fills full width, top/bottom padding for bars */
    .content {
        margin-left: 0;
        padding: 72px 16px 76px;
    }
}

@media (min-width: 769px) {
    .topbar { display: none !important; }
    .bottom-nav { display: none !important; }
    .sidebar-overlay { display: none !important; }
}

</style>
</head>
<body>

<!-- OVERLAY (mobile) -->
<div class="sidebar-overlay" id="overlay" onclick="closeSidebar()"></div>

<!-- MOBILE TOP BAR -->
<div class="topbar">
    <div class="topbar-logo">
        <div class="logo-icon">
            <i class="ti ti-brand-whatsapp"></i>
        </div>
        <h2>Sumahi CRM</h2>
    </div>
    <button class="hamburger" onclick="toggleSidebar()" aria-label="Open menu">
        <i class="ti ti-menu-2"></i>
    </button>
</div>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">

    <div class="logo">
        <div class="logo-icon">
            <i class="ti ti-brand-whatsapp"></i>
        </div>
        <div class="logo-text">
            <h2>Sumahi CRM</h2>
            <span>WhatsApp Business</span>
        </div>
    </div>

    <nav class="menu">
        <div class="menu-title">Main Menu</div>

        <a href="dashboard.php"    <?= $current=='dashboard.php'    ? 'class="active"' : '' ?>>
            <i class="ti ti-layout-dashboard"></i> Dashboard
        </a>
        <a href="contacts.php"     <?= $current=='contacts.php'     ? 'class="active"' : '' ?>>
            <i class="ti ti-users"></i> Contacts
        </a>
        <a href="conversations.php" <?= $current=='conversations.php' ? 'class="active"' : '' ?>>
            <i class="ti ti-message-circle"></i> Conversations
        </a>
        <a href="auto_replies.php" <?= $current=='auto_replies.php' ? 'class="active"' : '' ?>>
            <i class="ti ti-robot"></i> Auto Replies
        </a>
        <a href="broadcasts.php"   <?= $current=='broadcasts.php'   ? 'class="active"' : '' ?>>
            <i class="ti ti-speakerphone"></i> Broadcasts
        </a>
        <a href="settings.php"     <?= $current=='settings.php'     ? 'class="active"' : '' ?>>
            <i class="ti ti-settings"></i> Settings
        </a>
    </nav>

    <div class="sidebar-footer">
        <div class="admin-info">
            <div class="admin-avatar">A</div>
            <div>
                <div class="admin-name">Admin</div>
                <div class="admin-role">Administrator</div>
            </div>
        </div>
    </div>

</div>

<!-- BOTTOM NAV (mobile only) -->
<nav class="bottom-nav">
    <a href="dashboard.php"     <?= $current=='dashboard.php'    ? 'class="active"' : '' ?>>
        <i class="ti ti-layout-dashboard"></i> Home
    </a>
    <a href="conversations.php" <?= $current=='conversations.php' ? 'class="active"' : '' ?>>
        <i class="ti ti-message-circle"></i> Chats
    </a>
    <a href="broadcasts.php"    <?= $current=='broadcasts.php'   ? 'class="active"' : '' ?>>
        <i class="ti ti-speakerphone"></i> Broadcast
    </a>
    <a href="auto_replies.php"  <?= $current=='auto_replies.php' ? 'class="active"' : '' ?>>
        <i class="ti ti-robot"></i> Replies
    </a>
    <a href="settings.php"      <?= $current=='settings.php'     ? 'class="active"' : '' ?>>
        <i class="ti ti-settings"></i> Settings
    </a>
</nav>

<!-- MAIN CONTENT WRAPPER -->
<div class="content">

<script>
function toggleSidebar(){
    const s = document.getElementById('sidebar');
    const o = document.getElementById('overlay');
    s.classList.toggle('open');
    o.classList.toggle('visible');
}

function closeSidebar(){
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('overlay').classList.remove('visible');
}

// Close sidebar on nav link tap (mobile)
document.querySelectorAll('.sidebar a').forEach(a => {
    a.addEventListener('click', () => {
        if(window.innerWidth <= 768) closeSidebar();
    });
});
</script>