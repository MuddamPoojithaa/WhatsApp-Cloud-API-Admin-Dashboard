<?php

include 'header.php';

$totalContacts = $conn->query("
    SELECT COUNT(*) as total FROM contacts
")->fetch_assoc()['total'];

$totalMessages = $conn->query("
    SELECT COUNT(*) as total FROM messages
")->fetch_assoc()['total'];

$todayMessages = $conn->query("
    SELECT COUNT(*) as total FROM messages
    WHERE DATE(created_at) = CURDATE()
")->fetch_assoc()['total'];

$yesterdayMessages = $conn->query("
    SELECT COUNT(*) as total FROM messages
    WHERE DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
")->fetch_assoc()['total'];

$activeContacts = $conn->query("
    SELECT COUNT(DISTINCT wa_id) as total FROM messages
    WHERE DATE(created_at) = CURDATE()
")->fetch_assoc()['total'];

$weekMessages = $conn->query("
    SELECT COUNT(*) as total FROM messages
    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
")->fetch_assoc()['total'];

$monthMessages = $conn->query("
    SELECT COUNT(*) as total FROM messages
    WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())
")->fetch_assoc()['total'];

$monthContacts = $conn->query("
    SELECT COUNT(DISTINCT wa_id) as total FROM messages
    WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())
")->fetch_assoc()['total'];

$incoming = $conn->query("
    SELECT COUNT(*) as total FROM messages
    WHERE direction = 'incoming' AND DATE(created_at) = CURDATE()
")->fetch_assoc()['total'];

$outgoing = $conn->query("
    SELECT COUNT(*) as total FROM messages
    WHERE direction = 'outgoing' AND DATE(created_at) = CURDATE()
")->fetch_assoc()['total'];

$todayTrend = $yesterdayMessages > 0
    ? round((($todayMessages - $yesterdayMessages) / $yesterdayMessages) * 100)
    : 0;

/* 7-day sparkline data */
$sparkline = [];
for ($d = 6; $d >= 0; $d--) {
    $r = $conn->query("
        SELECT COUNT(*) as total FROM messages
        WHERE DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL $d DAY)
    ")->fetch_assoc();
    $sparkline[] = (int)$r['total'];
}

/* Message type breakdown */
$typeResult = $conn->query("
    SELECT message_type, COUNT(*) as total
    FROM messages
    GROUP BY message_type
    ORDER BY total DESC
    LIMIT 5
");
$types = [];
while ($row = $typeResult->fetch_assoc()) {
    $types[] = $row;
}

/* Sent vs received ratio */
$totalIncoming = $conn->query("SELECT COUNT(*) as t FROM messages WHERE direction='incoming'")->fetch_assoc()['t'];
$totalOutgoing = $conn->query("SELECT COUNT(*) as t FROM messages WHERE direction='outgoing'")->fetch_assoc()['t'];

/* Recent conversations */
$recent = $conn->query("
    SELECT m.wa_id,
           m.message,
           m.direction,
           m.status,
           MAX(m.created_at) AS last_msg,
           COUNT(m.id) AS msg_count,
           c.name
    FROM messages m
    LEFT JOIN contacts c ON c.wa_id = m.wa_id
    GROUP BY m.wa_id
    ORDER BY last_msg DESC
    LIMIT 6
");

function initials(string $name): string {
    $words = array_filter(explode(' ', trim($name)));
    return strtoupper(implode('', array_map(fn($w) => $w[0], array_slice($words, 0, 2))));
}

function formatContact(string $name, string $waId): string {
    if (!empty($name)) return $name;
    $num = preg_replace('/\D/', '', $waId);
    if (strlen($num) >= 10) {
        $cc    = substr($num, 0, strlen($num) - 10);
        $local = substr($num, -10);
        $fmt   = substr($local, 0, 5) . ' ' . substr($local, 5);
        return ($cc ? '+' . $cc . ' ' : '') . $fmt;
    }
    return $waId;
}

function timeAgo(string $dt): string {
    $d = time() - strtotime($dt);
    if ($d < 60)    return $d . 's ago';
    if ($d < 3600)  return round($d / 60) . 'm ago';
    if ($d < 86400) return round($d / 3600) . 'h ago';
    return round($d / 86400) . 'd ago';
}

$typeIcons = [
    'text'     => ['ti-message',        '#EEEDFE','#534AB7'],
    'image'    => ['ti-photo',          '#E1F5EE','#0F6E56'],
    'audio'    => ['ti-microphone',     '#E6F1FB','#185FA5'],
    'video'    => ['ti-video',          '#FAEEDA','#854F0B'],
    'document' => ['ti-file-text',      '#FAECE7','#993C1D'],
    'sticker'  => ['ti-mood-smile',     '#F1EFE8','#444441'],
    'location' => ['ti-map-pin',        '#E1F5EE','#0F6E56'],
    'button'   => ['ti-cursor-text',    '#EEEDFE','#534AB7'],
    'template' => ['ti-layout-grid',    '#FAEEDA','#854F0B'],
];

$avatarPalette = [
    ['#EEEDFE','#534AB7'],
    ['#E1F5EE','#0F6E56'],
    ['#E6F1FB','#185FA5'],
    ['#FAEEDA','#854F0B'],
    ['#FAECE7','#993C1D'],
    ['#F1EFE8','#444441'],
];

?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<style>
*, *::before, *::after { box-sizing: border-box; }

/* ── Topbar ─────────────────────────────────────────────── */
.topbar {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 20px; gap: 10px;
}
.topbar-eyebrow {
    font-size: 11px; color: #bbb;
    letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 4px;
}
.page-title {
    font-size: 20px; font-weight: 500;
    color: #bbb; letter-spacing: -0.5px; margin: 0;
}
.topbar-right { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }
.pill {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 11px; padding: 5px 10px; border-radius: 20px;
    border: 0.5px solid rgba(0,0,0,0.12); color: #888;
    background: #fff; cursor: default; white-space: nowrap;
}
.pill i { font-size: 12px; }
.pill.clickable { cursor: pointer; }
.pill.clickable:hover { background: #f5f5f5; }
/* Hide date pill on small screens */
.pill-date { display: inline-flex; }
.live-dot {
    width: 6px; height: 6px; border-radius: 50%;
    background: #1D9E75; animation: livepulse 2s infinite; flex-shrink: 0;
}
@keyframes livepulse { 0%,100%{opacity:1} 50%{opacity:.3} }

/* ── KPI Grid ────────────────────────────────────────────── */
.stats {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 8px;
    margin-bottom: 12px;
}
.card {
    background: #fff;
    border: 0.5px solid rgba(0,0,0,0.08);
    border-radius: 14px;
    padding: 12px 14px 10px;
    position: relative; overflow: hidden;
    transition: border-color .15s, transform .15s;
}
.card:hover { border-color: rgba(0,0,0,0.15); transform: translateY(-1px); }
.card::before {
    content: ''; position: absolute;
    top: 0; left: 0; width: 100%; height: 2px;
}
.card:nth-child(1)::before { background: #7F77DD; }
.card:nth-child(2)::before { background: #1D9E75; }
.card:nth-child(3)::before { background: #378ADD; }
.card:nth-child(4)::before { background: #BA7517; }
.card:nth-child(5)::before { background: #D85A30; }
.card-top {
    display: flex; align-items: flex-start;
    justify-content: space-between; margin-bottom: 10px;
}
.card-icon {
    width: 30px; height: 30px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; flex-shrink: 0;
}
.card:nth-child(1) .card-icon { background: #EEEDFE; color: #534AB7; }
.card:nth-child(2) .card-icon { background: #E1F5EE; color: #0F6E56; }
.card:nth-child(3) .card-icon { background: #E6F1FB; color: #185FA5; }
.card:nth-child(4) .card-icon { background: #FAEEDA; color: #854F0B; }
.card:nth-child(5) .card-icon { background: #FAECE7; color: #993C1D; }
.card-trend {
    font-size: 10px; font-weight: 500;
    padding: 2px 6px; border-radius: 10px;
    display: inline-flex; align-items: center; gap: 2px;
}
.trend-up   { background: #E1F5EE; color: #085041; }
.trend-down { background: #FCEBEB; color: #791F1F; }
.card h1 {
    font-size: 22px; font-weight: 500; color: #1a1a1a;
    letter-spacing: -0.8px; line-height: 1; margin: 0 0 3px 0;
}
.card h4 {
    font-size: 10px; font-weight: 400; color: #bbb; margin: 0 0 8px 0;
}
.card-bar-track {
    height: 2px; border-radius: 1px;
    background: rgba(0,0,0,0.06); overflow: hidden;
}
.card-bar-fill { height: 100%; border-radius: 1px; }
.card:nth-child(1) .card-bar-fill { background: #7F77DD; }
.card:nth-child(2) .card-bar-fill { background: #1D9E75; }
.card:nth-child(3) .card-bar-fill { background: #378ADD; }
.card:nth-child(4) .card-bar-fill { background: #BA7517; }
.card:nth-child(5) .card-bar-fill { background: #D85A30; }

/* ── Sparkline Panel ─────────────────────────────────────── */
.spark-panel {
    background: #fff;
    border: 0.5px solid rgba(0,0,0,0.08);
    border-radius: 14px;
    padding: 14px 16px;
    margin-bottom: 12px;
}
.spark-head {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 12px;
}
.spark-title { font-size: 13px; font-weight: 500; color: #1a1a1a; }
.spark-meta  { font-size: 11px; color: #bbb; }

/* ── Ratio Bar ───────────────────────────────────────────── */
.ratio-wrap { display: flex; align-items: center; gap: 10px; margin-top: 10px; }
.ratio-bar {
    flex: 1; height: 6px; border-radius: 3px;
    background: #E6F1FB; overflow: hidden;
}
.ratio-fill {
    height: 100%; border-radius: 3px;
    background: #1D9E75; transition: width .6s ease;
}
.ratio-label { font-size: 11px; color: #888; white-space: nowrap; }

/* ── Bottom Grid ─────────────────────────────────────────── */
.bottom-grid {
    display: grid;
    grid-template-columns: 1.4fr 1fr;
    gap: 12px;
}
.panel {
    background: #fff;
    border: 0.5px solid rgba(0,0,0,0.08);
    border-radius: 14px; overflow: hidden;
}
.panel-head {
    display: flex; align-items: center; justify-content: space-between;
    padding: 12px 16px;
    border-bottom: 0.5px solid rgba(0,0,0,0.06);
}
.panel-title { font-size: 13px; font-weight: 500; color: #1a1a1a; }
.panel-action {
    font-size: 11px; color: #bbb; text-decoration: none;
    display: inline-flex; align-items: center; gap: 3px;
}
.panel-action:hover { color: #888; }

/* ── Chat Rows ───────────────────────────────────────────── */
.chat-row {
    display: flex; align-items: center; gap: 12px;
    padding: 10px 16px;
    border-bottom: 0.5px solid rgba(0,0,0,0.05);
    cursor: pointer; transition: background .12s;
}
.chat-row:last-child { border-bottom: none; }
.chat-row:hover { background: #fafafa; }
.avatar {
    width: 36px; height: 36px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 12px; font-weight: 500; flex-shrink: 0;
}
.chat-info { flex: 1; min-width: 0; }
.chat-name {
    font-size: 13px; font-weight: 500; color: #1a1a1a;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 2px;
}
.chat-preview {
    font-size: 11px; color: #bbb;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.chat-right { display: flex; flex-direction: column; align-items: flex-end; gap: 5px; flex-shrink: 0; }
.chat-time  { font-size: 10px; color: #ccc; }
.dir-badge  {
    font-size: 9px; font-weight: 500; padding: 1px 6px; border-radius: 8px;
}
.dir-in  { background: #E1F5EE; color: #085041; }
.dir-out { background: #E6F1FB; color: #185FA5; }

/* ── Stat Rows ───────────────────────────────────────────── */
.stat-row {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 16px;
    border-bottom: 0.5px solid rgba(0,0,0,0.05);
}
.stat-row:last-child { border-bottom: none; }
.stat-left { display: flex; align-items: center; gap: 10px; }
.stat-icon-wrap {
    width: 30px; height: 30px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; flex-shrink: 0;
}
.stat-label { font-size: 12px; color: #555; }
.stat-sub   { font-size: 10px; color: #ccc; margin-top: 1px; }
.stat-right { display: flex; align-items: center; gap: 8px; }
.stat-bar-track {
    width: 60px; height: 3px;
    background: rgba(0,0,0,0.06); border-radius: 2px; overflow: hidden;
}
.stat-bar-fill { height: 100%; border-radius: 2px; }
.stat-val { font-size: 13px; font-weight: 500; color: #1a1a1a; min-width: 32px; text-align: right; }

/* ══════════════════════════════════════════════════════════
   RESPONSIVE BREAKPOINTS
   ══════════════════════════════════════════════════════════ */

/* Tablet: ≤ 900px — collapse to 2×2 + 1 KPI grid */
@media (max-width: 900px) {
    .stats {
        grid-template-columns: repeat(3, 1fr);
    }
    .stats .card:last-child {
        /* 5th card spans full width in a 3-col grid when there's a leftover */
        grid-column: span 1;
    }
    .bottom-grid {
        grid-template-columns: 1fr;
    }
}

/* Mobile: ≤ 600px */
@media (max-width: 600px) {
    .topbar { margin-bottom: 16px; }
    .page-title { font-size: 17px; }
    .topbar-eyebrow { font-size: 10px; }

    /* Hide date pill to save space */
    .pill-date { display: none; }

    .pill { font-size: 10px; padding: 4px 9px; }

    /* KPIs: 2 columns on mobile */
    .stats {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
        margin-bottom: 10px;
    }
    /* 5th card full-width */
    .stats .card:last-child {
        grid-column: 1 / -1;
    }

    .card { padding: 10px 12px 9px; border-radius: 12px; }
    .card h1 { font-size: 20px; }
    .card h4 { font-size: 10px; margin-bottom: 6px; }
    .card-icon { width: 28px; height: 28px; font-size: 13px; }
    .card-trend { font-size: 9px; padding: 2px 5px; }

    .spark-panel { padding: 12px 14px; border-radius: 12px; }
    .spark-title { font-size: 12px; }

    .bottom-grid { grid-template-columns: 1fr; gap: 10px; }

    .panel { border-radius: 12px; }
    .panel-head { padding: 10px 14px; }

    .chat-row { padding: 9px 14px; gap: 10px; }
    .chat-name { font-size: 12px; }
    .avatar { width: 32px; height: 32px; font-size: 11px; }

    /* Hide mini bar on mobile stat rows to keep it clean */
    .stat-bar-track { display: none; }
    .stat-row { padding: 9px 14px; }
    .stat-label { font-size: 11px; }
}

/* Very small: ≤ 380px */
@media (max-width: 380px) {
    .stats { grid-template-columns: 1fr 1fr; gap: 6px; }
    .card h1 { font-size: 18px; }
    .topbar-right .pill-refresh span { display: none; } /* icon only */
}
</style>

<!-- Topbar -->
<div class="topbar">
    <div>
        <div class="topbar-eyebrow">WhatsApp CRM</div>
        <h1 class="page-title">Overview</h1>
    </div>
    <div class="topbar-right">
        <span class="pill"><span class="live-dot"></span>Live</span>
        <span class="pill pill-date"><i class="ti ti-calendar"></i><?= date('j M Y') ?></span>
        <span class="pill clickable pill-refresh" onclick="location.reload()"><i class="ti ti-refresh"></i><span>Refresh</span></span>
    </div>
</div>

<!-- KPI Cards -->
<div class="stats">
    <div class="card">
        <div class="card-top">
            <span class="card-icon"><i class="ti ti-users"></i></span>
            <span class="card-trend trend-up">↑ 12%</span>
        </div>
        <h1><?= number_format($totalContacts) ?></h1>
        <h4>Total contacts</h4>
        <div class="card-bar-track"><div class="card-bar-fill" style="width:72%"></div></div>
    </div>
    <div class="card">
        <div class="card-top">
            <span class="card-icon"><i class="ti ti-message-dots"></i></span>
            <span class="card-trend trend-up">↑ 8%</span>
        </div>
        <h1><?= number_format($totalMessages) ?></h1>
        <h4>Total messages</h4>
        <div class="card-bar-track"><div class="card-bar-fill" style="width:85%"></div></div>
    </div>
    <div class="card">
        <div class="card-top">
            <span class="card-icon"><i class="ti ti-device-mobile-message"></i></span>
            <span class="card-trend <?= $todayTrend >= 0 ? 'trend-up' : 'trend-down' ?>">
                <?= $todayTrend >= 0 ? '↑' : '↓' ?> <?= abs($todayTrend) ?>%
            </span>
        </div>
        <h1><?= number_format($todayMessages) ?></h1>
        <h4>Messages today</h4>
        <div class="card-bar-track"><div class="card-bar-fill" style="width:40%"></div></div>
    </div>
    <div class="card">
        <div class="card-top">
            <span class="card-icon"><i class="ti ti-calendar-stats"></i></span>
            <span class="card-trend trend-up">↑ 3%</span>
        </div>
        <h1><?= number_format($yesterdayMessages) ?></h1>
        <h4>Messages yesterday</h4>
        <div class="card-bar-track"><div class="card-bar-fill" style="width:58%"></div></div>
    </div>
    <div class="card">
        <div class="card-top">
            <span class="card-icon"><i class="ti ti-messages"></i></span>
            <span class="card-trend trend-up">↑ 21%</span>
        </div>
        <h1><?= number_format($activeContacts) ?></h1>
        <h4>Active chats today</h4>
        <div class="card-bar-track"><div class="card-bar-fill" style="width:30%"></div></div>
    </div>
</div>

<!-- Bottom panels -->
<div class="bottom-grid">

    <!-- Recent conversations -->
    <div class="panel">
        <div class="panel-head">
            <span class="panel-title">Recent conversations</span>
            <a href="conversations.php" class="panel-action">
                View all <i class="ti ti-arrow-right" style="font-size:11px"></i>
            </a>
        </div>
        <?php
        $i = 0;
        while ($row = $recent->fetch_assoc()):
            $displayName = formatContact($row['name'] ?? '', $row['wa_id']);
            $init        = initials($displayName);
            $preview     = htmlspecialchars(mb_strimwidth($row['message'] ?? '—', 0, 48, '…'));
            $ago         = timeAgo($row['last_msg']);
            $dirClass    = $row['direction'] === 'incoming' ? 'dir-in' : 'dir-out';
            $dirLabel    = $row['direction'] === 'incoming' ? 'in' : 'out';
            [$bg, $fg]   = $avatarPalette[$i % count($avatarPalette)];
            $i++;
        ?>
        <div class="chat-row">
            <div class="avatar" style="background:<?= $bg ?>;color:<?= $fg ?>"><?= $init ?></div>
            <div class="chat-info">
                <div class="chat-name"><?= htmlspecialchars($displayName) ?></div>
                <div class="chat-preview"><?= $preview ?></div>
            </div>
            <div class="chat-right">
                <span class="chat-time"><?= $ago ?></span>
                <span class="dir-badge <?= $dirClass ?>"><?= $dirLabel ?></span>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <!-- Activity breakdown -->
    <div class="panel">
        <div class="panel-head">
            <span class="panel-title">Activity breakdown</span>
            <span class="panel-action"><?= date('M Y') ?></span>
        </div>
        <?php
        $maxVal = max($weekMessages, $monthMessages, $monthContacts, $incoming, $outgoing, 1);
        $rows = [
            ['ti-messages',          '#EEEDFE','#534AB7','#7F77DD', 'This week',       $weekMessages,  'messages'],
            ['ti-chart-bar',         '#E1F5EE','#0F6E56','#1D9E75', 'This month',      $monthMessages, 'messages'],
            ['ti-users',             '#E6F1FB','#185FA5','#378ADD', 'Active contacts', $monthContacts, 'this month'],
            ['ti-arrow-down-circle', '#FAEEDA','#854F0B','#BA7517', 'Incoming today',  $incoming,      'received'],
            ['ti-arrow-up-circle',   '#FAECE7','#993C1D','#D85A30', 'Outgoing today',  $outgoing,      'sent'],
        ];
        foreach ($rows as [$icon, $ibg, $icolor, $barcolor, $label, $val, $sub]):
            $pct = min(100, round(($val / $maxVal) * 100));
        ?>
        <div class="stat-row">
            <div class="stat-left">
                <div class="stat-icon-wrap" style="background:<?= $ibg ?>;color:<?= $icolor ?>">
                    <i class="ti <?= $icon ?>"></i>
                </div>
                <div>
                    <div class="stat-label"><?= $label ?></div>
                    <div class="stat-sub"><?= $sub ?></div>
                </div>
            </div>
            <div class="stat-right">
                <div class="stat-bar-track">
                    <div class="stat-bar-fill" style="width:<?= $pct ?>%;background:<?= $barcolor ?>"></div>
                </div>
                <span class="stat-val"><?= number_format($val) ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</div>
<br>

<!-- 7-day Sparkline + ratio -->
<div class="spark-panel">
    <div class="spark-head">
        <span class="spark-title">Messages — last 7 days</span>
        <span class="spark-meta"><?= array_sum($sparkline) ?> total</span>
    </div>
    <canvas id="sparkChart" height="60"></canvas>
    <div class="ratio-wrap">
        <?php
        $total  = $totalIncoming + $totalOutgoing;
        $inPct  = $total > 0 ? round(($totalIncoming / $total) * 100) : 50;
        $outPct = 100 - $inPct;
        ?>
        <span class="ratio-label" style="color:#1D9E75;font-weight:500">
            <i class="ti ti-arrow-down-circle" style="font-size:12px"></i>
            <?= $inPct ?>% in
        </span>
        <div class="ratio-bar">
            <div class="ratio-fill" style="width:<?= $inPct ?>%"></div>
        </div>
        <span class="ratio-label" style="color:#378ADD;font-weight:500">
            <?= $outPct ?>% out
            <i class="ti ti-arrow-up-circle" style="font-size:12px"></i>
        </span>
    </div>
</div>

<script>
const ctx = document.getElementById('sparkChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_map(fn($i) => date('D', strtotime("-$i day")), range(6, 0))) ?>,
        datasets: [{
            data: <?= json_encode($sparkline) ?>,
            borderColor: '#7F77DD',
            borderWidth: 2,
            pointBackgroundColor: '#7F77DD',
            pointRadius: 3,
            pointHoverRadius: 5,
            fill: true,
            backgroundColor: (ctx) => {
                const g = ctx.chart.ctx.createLinearGradient(0, 0, 0, 80);
                g.addColorStop(0, 'rgba(127,119,221,0.15)');
                g.addColorStop(1, 'rgba(127,119,221,0)');
                return g;
            },
            tension: 0.4,
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false }, tooltip: {
            backgroundColor: '#1a1a1a',
            titleColor: '#fff',
            bodyColor: '#ccc',
            padding: 8,
            cornerRadius: 8,
        }},
        scales: {
            x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#bbb' } },
            y: { grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { font: { size: 11 }, color: '#bbb', precision: 0 }, beginAtZero: true }
        }
    }
});
</script>

<?php include 'footer.php'; ?>