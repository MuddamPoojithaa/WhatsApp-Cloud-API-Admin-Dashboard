<?php
include '../config.php';

if(isset($_POST['save'])){
    $site_name           = trim($_POST['site_name']);
    $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
    $dark_mode           = isset($_POST['dark_mode']) ? 1 : 0;
    $auto_reply          = isset($_POST['auto_reply']) ? 1 : 0;

    $config  = '<?php' . "\n\n";
    $config .= '$SITE_NAME = \'' . addslashes($site_name) . "';\n";
    $config .= '$EMAIL_NOTIFICATIONS = ' . $email_notifications . ";\n";
    $config .= '$DARK_MODE = ' . $dark_mode . ";\n";
    $config .= '$AUTO_REPLY = ' . $auto_reply . ";\n";

    file_put_contents('../config.php', $config);
    header('Location: settings.php?saved=1');
    exit;
}

$save_success = isset($_GET['saved']) && $_GET['saved'] == '1';

include 'header.php';
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<div class="st-page">

    <div class="st-topbar">
        <div>
            <h1 class="st-title">Settings</h1>
            <p class="st-subtitle">Manage your system preferences</p>
        </div>
    </div>

    <?php if($save_success){ ?>
    <div class="st-alert">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M22 4L12 14.01l-3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Settings saved successfully.
    </div>
    <?php } ?>

    <form method="POST" class="st-form">

        <!-- SYSTEM -->
        <div class="st-card">
            <div class="st-card-header">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
                    <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z" stroke="currentColor" stroke-width="2"/>
                </svg>
                System
            </div>
            <div class="st-card-body">
                <div class="st-field">
                    <label class="st-label">Website name</label>
                    <input type="text" name="site_name"
                           value="<?= htmlspecialchars($SITE_NAME ?? '') ?>"
                           placeholder="e.g. Sumahi Media CRM"
                           class="st-input">
                    <span class="st-hint">Shown in the browser tab and page header</span>
                </div>
            </div>
        </div>

        <!-- NOTIFICATIONS -->
        <div class="st-card">
            <div class="st-card-header">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Notifications
            </div>
            <div class="st-card-body">
                <div class="st-toggle-row">
                    <div class="st-toggle-info">
                        <span class="st-toggle-name">Email notifications</span>
                        <span class="st-toggle-desc">Receive email alerts for new messages and events</span>
                    </div>
                    <label class="st-switch">
                        <input type="checkbox" name="email_notifications"
                               <?= !empty($EMAIL_NOTIFICATIONS) ? 'checked' : '' ?>>
                        <span class="st-track"><span class="st-thumb"></span></span>
                    </label>
                </div>
                <div class="st-divider"></div>
                <div class="st-toggle-row">
                    <div class="st-toggle-info">
                        <span class="st-toggle-name">Auto reply messages</span>
                        <span class="st-toggle-desc">Automatically respond to incoming messages using your rules</span>
                    </div>
                    <label class="st-switch">
                        <input type="checkbox" name="auto_reply"
                               <?= !empty($AUTO_REPLY) ? 'checked' : '' ?>>
                        <span class="st-track"><span class="st-thumb"></span></span>
                    </label>
                </div>
            </div>
        </div>

        <!-- APPEARANCE -->
        <div class="st-card">
            <div class="st-card-header">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10Z" stroke="currentColor" stroke-width="2"/>
                    <path d="M2 12h20" stroke="currentColor" stroke-width="2"/>
                </svg>
                Appearance
            </div>
            <div class="st-card-body">
                <div class="st-toggle-row">
                    <div class="st-toggle-info">
                        <span class="st-toggle-name">Dark mode</span>
                        <span class="st-toggle-desc">Switch the interface to a dark colour scheme</span>
                    </div>
                    <label class="st-switch">
                        <input type="checkbox" name="dark_mode"
                               <?= !empty($DARK_MODE) ? 'checked' : '' ?>>
                        <span class="st-track"><span class="st-thumb"></span></span>
                    </label>
                </div>
            </div>
        </div>

        <!-- SAVE -->
        <div class="st-save-row">
            <button type="submit" name="save" class="st-save-btn">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M17 21v-8H7v8M7 3v5h8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Save changes
            </button>
        </div>

    </form>
</div>

<?php include 'footer.php'; ?>

<style>
/* ── Page ───────────────────────────────────────────────────── */
.st-page {
    max-width: 640px;
    margin: 0 auto;
    padding: 14px 0 48px;
    display: flex;
    flex-direction: column;
    gap: 14px;
}

/* ── Top bar ────────────────────────────────────────────────── */
.st-topbar { margin-bottom: 2px; }
.st-title    { font-size: 20px; font-weight: 500; color: #1a1a2e; margin: 0; line-height: 1.2; }
.st-subtitle { font-size: 12.5px; color: #b0b0b0; margin: 3px 0 0; }

/* ── Alert ──────────────────────────────────────────────────── */
.st-alert {
    display: flex; align-items: center; gap: 9px;
    background: #EAF3DE; border: 0.5px solid #C0DD97;
    border-radius: 10px; padding: 11px 16px;
    font-size: 13.5px; color: #27500A;
}
.st-alert svg { color: #3B6D11; flex-shrink: 0; }

/* ── Card ───────────────────────────────────────────────────── */
.st-card { background: #fff; border: 0.5px solid #e8e8e8; border-radius: 14px; overflow: hidden; }
.st-card-header {
    display: flex; align-items: center; gap: 8px;
    padding: 12px 18px; font-size: 13px; font-weight: 500;
    color: #1a1a2e; border-bottom: 0.5px solid #f0f0f0; background: #fafafa;
}
.st-card-header svg { color: #7F77DD; }
.st-card-body { padding: 18px; display: flex; flex-direction: column; gap: 0; }

/* ── Text field ─────────────────────────────────────────────── */
.st-field  { display: flex; flex-direction: column; gap: 5px; }
.st-label  { font-size: 11.5px; font-weight: 500; color: #888; text-transform: uppercase; letter-spacing: .05em; }
.st-input  {
    padding: 9px 13px; font-size: 13.5px;
    border: 0.5px solid #e0e0e0; border-radius: 10px;
    background: #f9f9f9; color: #1a1a2e; outline: none;
    transition: border-color .15s, background .15s;
    width: 100%; box-sizing: border-box;
    /* Prevents iOS zoom on focus (font-size must be ≥16px on iOS) */
    font-size: max(16px, 13.5px);
}
.st-input:focus { border-color: #7F77DD; background: #fff; }
.st-input::placeholder { color: #c0c0c0; }
.st-hint { font-size: 11.5px; color: #c0c0c0; }

/* ── Toggle row ─────────────────────────────────────────────── */
.st-toggle-row {
    display: flex; align-items: center;
    justify-content: space-between;
    gap: 16px; padding: 14px 0;
}
.st-toggle-info { display: flex; flex-direction: column; gap: 3px; flex: 1; min-width: 0; }
.st-toggle-name { font-size: 13.5px; font-weight: 500; color: #1a1a2e; }
.st-toggle-desc { font-size: 12px; color: #b0b0b0; }
.st-divider { height: 0.5px; background: #f0f0f0; }

/* ── Toggle switch ──────────────────────────────────────────── */
.st-switch { position: relative; flex-shrink: 0; cursor: pointer; }
.st-switch input { position: absolute; opacity: 0; width: 0; height: 0; }
.st-track {
    display: block; width: 44px; height: 24px;
    background: #e0e0e0; border-radius: 24px;
    position: relative; transition: background .2s;
}
.st-thumb {
    position: absolute; top: 3px; left: 3px;
    width: 18px; height: 18px; background: #fff; border-radius: 50%;
    transition: transform .2s; box-shadow: 0 1px 3px rgba(0,0,0,.15);
}
.st-switch input:checked + .st-track            { background: #534AB7; }
.st-switch input:checked + .st-track .st-thumb  { transform: translateX(20px); }

/* ── Save button ────────────────────────────────────────────── */
.st-save-row { display: flex; justify-content: flex-end; }
.st-save-btn {
    display: flex; align-items: center; gap: 8px;
    padding: 10px 24px; background: #534AB7; color: #fff;
    border: none; border-radius: 10px; font-size: 14px; font-weight: 500;
    cursor: pointer; transition: background .15s;
}
.st-save-btn:hover { background: #3C3489; }

/* ══════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════ */
@media (max-width: 640px) {
    .st-page { padding: 12px 0 40px; gap: 12px; }
    .st-title { font-size: 18px; }
    .st-card  { border-radius: 12px; }
    .st-card-header { padding: 11px 14px; }
    .st-card-body   { padding: 14px; }

    /* Toggle desc wraps cleanly — give it room */
    .st-toggle-row  { gap: 12px; padding: 12px 0; }
    .st-toggle-desc { font-size: 11.5px; }

    /* Bigger tap target for the switch */
    .st-track  { width: 48px; height: 26px; }
    .st-thumb  { width: 20px; height: 20px; }
    .st-switch input:checked + .st-track .st-thumb { transform: translateX(22px); }

    /* Save button full-width on mobile — easier to tap */
    .st-save-row { justify-content: stretch; }
    .st-save-btn { width: 100%; justify-content: center; padding: 13px; font-size: 15px; }
}

@media (max-width: 380px) {
    .st-toggle-name { font-size: 13px; }
    .st-toggle-desc { font-size: 11px; }
}
</style>