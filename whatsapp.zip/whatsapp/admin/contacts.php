<?php

include 'header.php';

/*
----------------------------------
GET CONTACTS WITH LAST MESSAGE
----------------------------------
*/

$contacts = $conn->query("
SELECT 
    c.id,
    c.wa_id,
    c.last_message_at,
    m.message AS last_message
FROM contacts c
LEFT JOIN messages m 
    ON m.wa_id = c.wa_id
    AND m.id = (
        SELECT MAX(id) 
        FROM messages 
        WHERE wa_id = c.wa_id
    )
ORDER BY c.last_message_at DESC
");

?>
<h1 class="page-title1">Contacts</h1>
<div class="topbar">
    <div class="topbar-left">
        <p class="topbar-eyebrow">WhatsApp CRM</p>
        <h1 class="page-title">Contacts</h1>
    </div>
    <div class="topbar-right">
        <div class="search-wrap">
            <svg class="search-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input
                type="text"
                id="searchInput"
                class="search-box"
                placeholder="Search contacts…"
            >
        </div>
    </div>
</div>

<div class="panel">

    <div class="panel-head">
        <div class="panel-head-left">
            <span class="panel-title">All Contacts</span>
            <span class="contact-count-badge"><?= $contacts->num_rows ?></span>
        </div>
        <div class="panel-head-right">
            <button class="export-btn" onclick="exportCSV()">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                Export
            </button>
        </div>
    </div>

    <div class="table-wrap">
    <table class="crm-table" id="contactsTable">

        <thead>
            <tr>
                <th>Contact</th>
                <th>Last Message</th>
                <th>Last Activity</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>

        <tbody>

        <?php while($row = $contacts->fetch_assoc()): ?>

            <?php
            $phone = htmlspecialchars($row['wa_id']);
            $digits = preg_replace('/\D/', '', $phone);
            $initial = strtoupper(substr($digits, -2));
            $colorIndex = (int)($digits % 6);
            $avatarClasses = ['av-indigo','av-teal','av-rose','av-amber','av-sky','av-violet'];
            $avClass = $avatarClasses[$colorIndex];
            ?>

            <tr>

                <td>
                    <div class="contact-wrap">
                        <div class="avatar-sm <?= $avClass ?>">
                            <?= $initial ?>
                        </div>
                        <div>
                            <div class="contact-name"><?= $phone ?></div>
                            <div class="contact-sub">ID #<?= $row['id'] ?></div>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="message-cell">
                        <?= htmlspecialchars(
                            mb_strimwidth(
                                $row['last_message'] ?? 'No messages yet',
                                0,
                                60,
                                '…'
                            )
                        ) ?>
                    </div>
                </td>

                <td>
                    <span class="date-cell">
                        <?php if (!empty($row['last_message_at'])): ?>
                            <span class="date-main"><?= date('d M Y', strtotime($row['last_message_at'])) ?></span>
                            <span class="date-time"><?= date('H:i', strtotime($row['last_message_at'])) ?></span>
                        <?php else: ?>
                            <span class="date-empty">—</span>
                        <?php endif; ?>
                    </span>
                </td>

                <td>
                    <span class="status-pill active">
                        Active
                    </span>
                </td>

                <td>
                    <a href="conversations.php?phone=<?= urlencode($row['wa_id']) ?>" class="table-btn">
                        Open chat
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
                        </svg>
                    </a>
                </td>

            </tr>

        <?php endwhile; ?>

        </tbody>

    </table>
    </div>

    <div class="panel-footer">
        <span class="footer-count" id="visibleCount"><?= $contacts->num_rows ?> contacts</span>
    </div>

</div>

<style>
/* ─── Reset / Base ─────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; }

/* ─── Topbar ───────────────────────────────────────── */
.topbar {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    padding: 28px 32px 20px;
    gap: 16px;
}

.topbar-eyebrow {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: .08em;
    text-transform: uppercase;
    color: #25D366;
    margin: 0 0 4px;
}
.page-title1 {
    font-size: 18px;
    font-weight: 500;
    color: #1a1a2e;
  
    margin: -10px 0 8px;
    line-height: 1;
}
.page-title {
    font-size: 22px;
    font-weight: 700;
    color: #0F172A;
    margin: 0;
    letter-spacing: -.3px;
}

/* ─── Search ───────────────────────────────────────── */
.search-wrap {
    position: relative;
    display: flex;
    align-items: center;
}

.search-icon {
    position: absolute;
    left: 12px;
    color: #94A3B8;
    pointer-events: none;
}

.search-box {
    width: 260px;
    height: 38px;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    padding: 0 14px 0 36px;
    outline: none;
    font-size: 13px;
    color: #0F172A;
    background: #fff;
    transition: border-color .18s, box-shadow .18s;
}

.search-box::placeholder { color: #94A3B8; }

.search-box:focus {
    border-color: #25D366;
    box-shadow: 0 0 0 3px rgba(37, 211, 102, .12);
}

/* ─── Panel ────────────────────────────────────────── */
.panel {
   
    background: #fff;
    border: 1px solid #E2E8F0;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,.05), 0 4px 16px rgba(0,0,0,.04);
}

.panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 20px;
    border-bottom: 1px solid #F1F5F9;
    background: #FAFBFC;
}

.panel-head-left {
    display: flex;
    align-items: center;
    gap: 10px;
}

.panel-title {
    font-size: 13px;
    font-weight: 600;
    color: #0F172A;
}

.contact-count-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 22px;
    height: 20px;
    padding: 0 7px;
    border-radius: 20px;
    background: #F1F5F9;
    color: #64748B;
    font-size: 11px;
    font-weight: 600;
}

.export-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 32px;
    padding: 0 12px;
    border: 1px solid #E2E8F0;
    border-radius: 8px;
    background: #fff;
    color: #475569;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    transition: background .15s, border-color .15s;
}

.export-btn:hover {
    background: #F8FAFC;
    border-color: #CBD5E1;
}

/* ─── Table ────────────────────────────────────────── */
.table-wrap { width: 100%; overflow: visible; }

.crm-table {
    width: 100%;
    border-collapse: collapse;
}

.crm-table thead tr {
    background: #F8FAFC;
}

.crm-table th {
    font-size: 10.5px;
    text-transform: uppercase;
    letter-spacing: .07em;
    color: #94A3B8;
    font-weight: 600;
    padding: 10px 20px;
    text-align: left;
    white-space: nowrap;
    border-bottom: 1px solid #F1F5F9;
}

.crm-table td {
    padding: 13px 20px;
    border-bottom: 1px solid #F8FAFC;
    vertical-align: middle;
}

.crm-table tbody tr:last-child td { border-bottom: none; }

.crm-table tbody tr {
    transition: background .12s;
}

.crm-table tbody tr:hover {
    background: #F8FAFC;
}

/* ─── Avatar ───────────────────────────────────────── */
.contact-wrap {
    display: flex;
    align-items: center;
    gap: 12px;
}

.avatar-sm {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: 700;
    flex-shrink: 0;
    letter-spacing: .02em;
}

.av-indigo { background: #EEF2FF; color: #4338CA; }
.av-teal   { background: #F0FDF9; color: #0D9488; }
.av-rose   { background: #FFF1F2; color: #E11D48; }
.av-amber  { background: #FFFBEB; color: #D97706; }
.av-sky    { background: #F0F9FF; color: #0284C7; }
.av-violet { background: #F5F3FF; color: #7C3AED; }

.contact-name {
    font-size: 13px;
    font-weight: 500;
    color: #0F172A;
    letter-spacing: -.1px;
}

.contact-sub {
    font-size: 11px;
    color: #94A3B8;
    margin-top: 2px;
}

/* ─── Message Cell ─────────────────────────────────── */
.message-cell {
    font-size: 12.5px;
    color: #64748B;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

/* ─── Date Cell ────────────────────────────────────── */
.date-cell {
    display: flex;
    flex-direction: column;
    gap: 1px;
}

.date-main {
    font-size: 12.5px;
    color: #334155;
    font-weight: 500;
}

.date-time {
    font-size: 11px;
    color: #94A3B8;
}

.date-empty {
    font-size: 13px;
    color: #CBD5E1;
}

/* ─── Status Pill ──────────────────────────────────── */
.status-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 500;
    white-space: nowrap;
}

.status-pill.active {
    background: #F0FDF9;
    color: #0D9488;
    border: 1px solid #CCFBF1;
}

.status-pill.active::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #14B8A6;
    flex-shrink: 0;
}

/* ─── Open Chat Button ─────────────────────────────── */
.table-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 7px 13px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 12px;
    font-weight: 500;
    color: #0F172A;
    background: #F1F5F9;
    border: 1px solid transparent;
    transition: background .15s, color .15s, border-color .15s;
    white-space: nowrap;
}

.table-btn:hover {
    background: #0F172A;
    color: #fff;
}

/* ─── Panel Footer ─────────────────────────────────── */
.panel-footer {
    padding: 12px 20px;
    border-top: 1px solid #F1F5F9;
    background: #FAFBFC;
}

.footer-count {
    font-size: 11.5px;
    color: #94A3B8;
}

/* ─── Search JS filtering ──────────────────────────── */
.row-hidden { display: none; }
</style>

<script>
(function () {
    // ── Search filtering ──
    const input   = document.getElementById('searchInput');
    const rows    = document.querySelectorAll('#contactsTable tbody tr');
    const countEl = document.getElementById('visibleCount');

    input.addEventListener('input', function () {
        const q = this.value.trim().toLowerCase();
        let visible = 0;
        rows.forEach(function (row) {
            const phone = row.querySelector('.contact-name')?.textContent.toLowerCase() ?? '';
            const match = phone.includes(q);
            row.classList.toggle('row-hidden', !match);
            if (match) visible++;
        });
        countEl.textContent = visible + ' contact' + (visible === 1 ? '' : 's');
    });
})();

// ── CSV Export ──
function exportCSV() {
    const table   = document.getElementById('contactsTable');
    const rows    = table.querySelectorAll('tr:not(.row-hidden)');
    const csvRows = [];

    rows.forEach(function (row) {
        const cols = row.querySelectorAll('th, td');
        const values = Array.from(cols).map(function (col) {
            // Skip the last "Open chat" action column
            const btn = col.querySelector('.table-btn');
            if (btn) return '';
            let text = col.innerText.replace(/\n/g, ' ').trim();
            // Wrap in quotes if contains comma or quote
            if (text.includes(',') || text.includes('"')) {
                text = '"' + text.replace(/"/g, '""') + '"';
            }
            return text;
        });
        // Drop trailing empty column
        while (values.length && values[values.length - 1] === '') values.pop();
        csvRows.push(values.join(','));
    });

    const csvString = csvRows.join('\n');
    const blob      = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url       = URL.createObjectURL(blob);
    const link      = document.createElement('a');
    const date      = new Date().toISOString().slice(0, 10);

    link.href     = url;
    link.download = 'contacts-' + date + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}
</script>

<?php include 'footer.php'; ?>