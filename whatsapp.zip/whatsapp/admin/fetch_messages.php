<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

include '../db.php';

$phone = $_GET['phone'] ?? '';
$last_id = intval($_GET['last_id'] ?? 0);

if (empty($phone)) {
    echo json_encode(["messages" => []]);
    exit;
}

$stmt = $conn->prepare("
    SELECT id, message, direction, created_at
    FROM messages
    WHERE wa_id = ?
    AND id > ?
    ORDER BY id ASC
");

$stmt->bind_param("si", $phone, $last_id);
$stmt->execute();

$result = $stmt->get_result();

$messages = [];

while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

echo json_encode([
    "messages" => $messages
]);
exit;